﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedLibrary
{
    public enum MessageType
    {
        AddFriendRequest,   // args: yourUsername, otherUsername
        AddToChatRequest,   // args: yourUsername, usernameToAdd, chatID
        LeaveChatRequst,    // args: yourUsername, chatID
        LogInRequest,       // args: yourUsername, yourHashedPassword
        LogInResponse,      // args: yourOnlineAccount (sent on your initial login)
        LogOutRequest,      // args: yourUsername
        UpdateAccount,      // args: yourOnlineAccount (sent when a friend logs in/out)
        UpdateConversation, // args: yourConversation, yourConversationID
        RecieveChatMessage, // args: chatID, message
        SendChatMessage,    // args: yourUsername, chatID, message
        StartChatRequest,   // args: yourUsername, otherUsername
        StartChatResponse,  // args: yourConversation, yourConversationID
        ServerFault,        // args: null
        RemoveFriendRequest, // args:youUsername, otherUsername
        RemoveFriendResponse // args: message to be displayed (string)
    }
    public interface IMessage
    {
        Object[] Args { get; set;}
        MessageType TypeOfMessage { get; }

    }
}
