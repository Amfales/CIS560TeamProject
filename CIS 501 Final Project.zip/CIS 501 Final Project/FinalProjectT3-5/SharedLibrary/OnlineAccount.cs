﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedLibrary
{
    public class OnlineAccount : Account
    {
        private Account _a;
        private List<int> _conversations;
        private List<string> _onlineFriends;

        public OnlineAccount(Account other) : base((other == null) ? null : other.Username, (other == null) ? null : other.PasswordHash)
        {
            if (other != null)
            {
                _a = other;
                _conversations = new List<int>();
                _onlineFriends = new List<string>();
            }
            else
            {
                _a = new Account("","");
            }
        }

        public void SetAccount(Account other)
        {
            _a = other;
        }
        public new string PasswordHash
        {
            get
            {
                return _a.PasswordHash;
            }
        }

        public new string Username
        {
            get
            {
                return _a.Username;
            }
        }
        public new List<string> Friends
        {
            get
            {
                return _a.Friends;
            }
            set
            {
                _a.Friends = value;
            }
        }

        public void AddConversation(int uID)
        {
            _conversations.Add(uID);
        }

        public List<int> Conversations
        {
            get
            {
                return _conversations;
            }
            set
            {
                _conversations = value;
            }
        }

        public void AddOnlineFriend(string username)
        {
            _onlineFriends.Add(username);
        }

        public List<string> OnlineFriends
        {
            get
            {
                return _onlineFriends;
            }
            set
            {
                _onlineFriends = value;
            }
        }
    }
}