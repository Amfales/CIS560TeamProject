﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebSocketSharp;
using SharedLibrary;
using Newtonsoft.Json.Linq;

namespace FinalProjectT3_5
{
    public partial class MainForm : Form
    {
        /// <summary>
        /// The OnlineAccount object this form represents
        /// </summary>
        private OnlineAccount _account;

        /// <summary>
        /// The dictionary of chats this account has open. Dictionary was used for easier lookup
        /// </summary>
        private Dictionary<int, ChatForm> _chats;

        /// <summary>
        /// The controller for the form
        /// </summary>
        private ClientChatSocket _socket;

        /// <summary>
        /// The delegate to execute when a message is recieved
        /// </summary>
        /// <param name="message">The recieved message</param>
        public delegate void OnMessage(string message);

        /// <summary>
        /// Constructor for the class. Initializes all components and adds some minor quality improvements
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
            uxMainGB.Enabled = false;
            uxMainGB.Visible = false;
            uxLoginGB.BringToFront();
            //uxLoginGB.Enabled = false;
            uxIPgb.Enabled = true;
            uxIPgb.BringToFront();
            _chats = new Dictionary<int, ChatForm>();

            uxIP.KeyDown += (sender, e) => { if (e.KeyCode == Keys.Enter) uxIPbtn_Click(sender, e); };
            uxUsername.KeyDown += (sender, e) => { if (e.KeyCode == Keys.Enter && uxPassword.Text != "") uxLogInBtn_Click(sender, e); };
            uxPassword.KeyDown += (sender, e) => { if (e.KeyCode == Keys.Enter && uxUsername.Text != "") uxLogInBtn_Click(sender, e); };
        }

        /// <summary>
        /// Click event for the login button. Creates and sends a LoginRequest to the server
        /// </summary>
        /// <param name="sender">The login button</param>
        /// <param name="e">The event arguments</param>
        private void uxLogInBtn_Click(object sender, EventArgs e)
        {
            string _username = uxUsername.Text;
            string rawpass = uxPassword.Text;
            string _hashpass = "" + rawpass.GetHashCode();

            if (_username == "" || rawpass == "")
            {
                MessageBox.Show("Invalid username or password.");
            }
            else
            {

                SharedLibrary.Message login = new SharedLibrary.Message(SharedLibrary.MessageType.LogInRequest, new object[] { _username, _hashpass });
                _socket.SendMessage(login);
            }
        }

        /// <summary>
        /// Click event for the start chat button. Creates and sends a StartChatRequest for the selected user to the server
        /// </summary>
        /// <param name="sender">The start chat button</param>
        /// <param name="e">The event arguments</param>
        private void uxStartChatBtn_Click(object sender, EventArgs e)
        {
            string name = "" + uxLoggedInLB.SelectedItem;
            if (_account.Username == name)
            {
                MessageBox.Show("Cannot chat with yourself.\nPlease select an online contact to begin a chat.");
            }
            else
            {
                SharedLibrary.Message startchat = new SharedLibrary.Message(SharedLibrary.MessageType.StartChatRequest, new object[] { _account.Username, name });
                _socket.SendMessage(startchat);
            }
            uxLoggedInLB.ClearSelected();
        }

        /// <summary>
        /// The click event for the add contact button. Creates and sends an AddFriendRequest to the given contact to the server
        /// </summary>
        /// <param name="sender">The add contact button</param>
        /// <param name="e">The event arguments</param>
        private void uxAddContactBtn_Click(object sender, EventArgs e)
        {
            string name = uxAddUsername.Text;
            if (_account.Username == name)
            {
                MessageBox.Show("Cannot add yourself as a contact.\nPlease enter a valid username to add a contact.");
            }
            else
            {
                SharedLibrary.Message addcont = new SharedLibrary.Message(SharedLibrary.MessageType.AddFriendRequest, new object[] { _account.Username, name });
                _socket.SendMessage(addcont);
            }
            uxAddUsername.Text = "";
        }

        /// <summary>
        /// The click event for the logout button. Calls the Logout() helper function
        /// </summary>
        /// <param name="sender">The logout button</param>
        /// <param name="e">The event arguments</param>
        private void uxLogoutBtn_Click(object sender, EventArgs e)
        {
            Logout();
        }

        /// <summary>
        /// The close event for this form. Calls the Logout() helper function if the user is logged in and the connection is alive
        /// </summary>
        /// <param name="sender">This form</param>
        /// <param name="e">The event</param>
        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (_account == null || !_socket.IsAlive)
            {
                return;
            }
            Logout();
        }

        /// <summary>
        /// Creates and sends a LogOutRequest to the server and returns the form to the login state.
        /// </summary>
        private void Logout()
        {
            foreach (ChatForm cf in _chats.Values)
            {
                Invoke(new Action(() => { cf.Close(); }));
            }
            SharedLibrary.Message logout = new SharedLibrary.Message(SharedLibrary.MessageType.LogOutRequest, new object[] { _account.Username });
            _socket.SendMessage(logout);
            if (_socket.IsAlive)
            {
                uxLoginGB.Enabled = true;
                uxLoginGB.Visible = true;
                uxMainGB.Enabled = false;
                uxMainGB.Visible = false;
                uxLoginGB.BringToFront();
                _account = null;
            }
        }

        /// <summary>
        /// The click event for the IP button. Creates a ClientChatSocket (controller) with the given IP. Passes the socket's MessageRecieved event
        /// </summary>
        /// <param name="sender">The IP button</param>
        /// <param name="e">The event arguments</param>
        private void uxIPbtn_Click(object sender, EventArgs e)
        {
            string ip = uxIP.Text;
            if (ip == "") return;
            _socket = new ClientChatSocket(ip, ReturnToIP);
            //WS onmessage stuff
            _socket.MessageReceived += (me) =>
            {
                string jsonString = me.ToString();
                SharedLibrary.Message message = JSONizer.ConvertToMessage(jsonString);
                DoMessageAction(message);
            };

            if (!_socket.IsAlive)
            {
                MessageBox.Show("Connection Error: Please check the given IP and try again.");
            }
            else
            {
                uxIPgb.Enabled = false;
                uxIPgb.Visible = false;
                uxLoginGB.Enabled = true;
                uxLoginGB.Visible = true;
                uxLoginGB.BringToFront();
                uxUsername.Focus();
            }

        }

        /// <summary>
        /// Performs an action depending on the given message
        /// </summary>
        /// <param name="message">The given method</param>
        private void DoMessageAction(IMessage message)
        {
            switch (message.TypeOfMessage)
            {
                //Logs the user in, updates the account, and sets the form to the logged in state if the request was successful.
                case MessageType.LogInResponse:
                    if (message.Args[0] == null)
                    {
                        MessageBox.Show("Login failed. Please check your password and try again.");
                    }
                    else
                    {
                        _account = ((JObject)message.Args[0]).ToObject<SharedLibrary.OnlineAccount>();
                        Account tempaccount = ((JObject)message.Args[0]).ToObject<SharedLibrary.Account>();
                        _account.SetAccount(tempaccount);
                        Invoke(new Action(() => { UpdateForm(); }));

                        Invoke(new Action(() =>
                        {
                            uxLoginGB.Enabled = false;
                            uxLoginGB.Visible = false;
                            uxMainGB.Enabled = true;
                            uxMainGB.Visible = true;
                            uxMainGB.BringToFront();
                            uxAddUsername.Focus();
                            uxAccountLabel.Text = _account.Username;
                        }));
                    }
                    break;

                //Starts a chat with a different user. Creates and shows a ChatForm and adds it to _chats if the request was successful.
                case MessageType.StartChatResponse:
                    if (message.Args[0] == null)
                    {
                        MessageBox.Show("Chat could not be started.");
                    }
                    else
                    {
                        Conversation convo = ((JObject)message.Args[0]).ToObject<Conversation>();
                        int id = Convert.ToInt32(message.Args[1]);

                        this.Invoke(new Action(() =>
                        {
                            ChatForm chat = new ChatForm(convo, _account.Username, _socket);
                            _chats[id] = chat;
                            chat.Show();
                        }));
                    }
                    break;

                //Updates the current account and the form subsequently if the request was successful.
                case MessageType.UpdateAccount:
                    if (message.Args[0] == null)
                    {
                        MessageBox.Show("Couldn't add friend.");
                    }
                    else
                    {
                        _account = ((JObject)message.Args[0]).ToObject<SharedLibrary.OnlineAccount>();
                        Account tempaccount = ((JObject)message.Args[0]).ToObject<SharedLibrary.Account>();
                        _account.SetAccount(tempaccount);
                        Invoke(new Action(() => { UpdateForm(); }));
                    }
                    break;

                //Updates a given ChatForm with a new conversation if the request was successful. Otherwise, the ChatForm is closed.
                case MessageType.UpdateConversation:
                    if (message.Args[0] == null)
                    {
                        MessageBox.Show("You're the last one in this chat. The chat will now close");
                        int id = Convert.ToInt32(message.Args[1]);
                        Invoke(new Action(() => _chats[id].Close()));
                        _chats.Remove(id);
                    }
                    else
                    {
                        int id = Convert.ToInt32(message.Args[1]);
                        Conversation convo = ((JObject)message.Args[0]).ToObject<SharedLibrary.Conversation>();
                        Invoke(new Action(() =>
                        {
                            _chats[id].UpdateChat(convo);
                        }));
                    }
                    break;

                //Updates a ChatForm with a new message if the request was successful.
                case MessageType.RecieveChatMessage:
                    if (message.Args[0] == null)
                    {
                        MessageBox.Show("Error recieving message.");
                    }
                    else
                    {
                        int chatID = Convert.ToInt32(message.Args[0]);
                        string msg = message.Args[1].ToString();
                        Invoke(new Action(() =>
                        {
                            _chats[chatID].UpdateLines(msg);
                        }));
                    }
                    break;

                //Displays a messsagebox with an error message if removing a friend was unsuccessful
                case MessageType.RemoveFriendResponse:
                    {
                        MessageBox.Show(Convert.ToString(message.Args[0]));
                        break;
                    }

                //Returns this form to the IP state
                case MessageType.ServerFault:
                    Invoke(new Action(() =>
                    {
                        ReturnToIP();
                    }));
                    break;
            }
        }

        /// <summary>
        /// Updates the form's controls
        /// </summary>
        private void UpdateForm()
        {
            Invoke(new Action(() =>
            {
                List<string> offline;

                uxLoggedInLB.DataSource = null;
                uxLoggedInLB.DataSource = _account.OnlineFriends;

                //Update other listbox
                uxContactLB.SelectionMode = SelectionMode.One;
                offline = _account.Friends.Where(f => !_account.OnlineFriends.Contains(f)).ToList();
                uxContactLB.DataSource = null;
                uxContactLB.DataSource = offline;
                uxContactLB.SelectionMode = SelectionMode.None;
            }));
        }

        /// <summary>
        /// Returns the form to the IP state
        /// </summary>
        private void ReturnToIP()
        {
            Invoke(new Action(() =>
            {
                MessageBox.Show("Server connection is dead. Going back to main menu.");
                foreach (KeyValuePair<int, ChatForm> pair in _chats)
                {
                    pair.Value.Close();
                }
                _chats.Clear();

                uxIPgb.Enabled = true;
                uxIPgb.Visible = true;
                uxMainGB.Enabled = false;
                uxMainGB.Visible = false;
                uxIPgb.BringToFront();
            }));
        }

        /// <summary>
        /// The click event for the remove contact button. Creates and sends a RemoveContactRequest with the given contact
        /// </summary>
        /// <param name="sender">The remove contact button</param>
        /// <param name="e">The event arguments</param>
        private void uxRemoveContact_Click(object sender, EventArgs e)
        {
            string username = uxAddUsername.Text;
            if (!_account.Friends.Contains(username))
            {
                MessageBox.Show("Couldn't remove contact.");
                return;
            }

            SharedLibrary.Message remove = new SharedLibrary.Message(SharedLibrary.MessageType.RemoveFriendRequest, new object[] { _account.Username, username });
            _socket.SendMessage(remove);

        }
    }
}
