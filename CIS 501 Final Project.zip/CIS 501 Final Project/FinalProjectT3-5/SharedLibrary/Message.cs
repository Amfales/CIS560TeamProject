﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SharedLibrary
{
    public class Message : IMessage
    {
        object[] _args;
        MessageType _mt;

        public Message(MessageType type, object[] args)
        {
            _args = args;
            _mt = type;
        }
        public object[] Args
        {
            get
            {
                return _args;
            }

            set
            {
                _args = value;
            }
        }

        [JsonConverter(typeof(Newtonsoft.Json.Converters.StringEnumConverter))]
        public MessageType TypeOfMessage
        {
            get
            {
                return _mt;
            }
            set
            {
                _mt = value;
            }
        }
    }
}
