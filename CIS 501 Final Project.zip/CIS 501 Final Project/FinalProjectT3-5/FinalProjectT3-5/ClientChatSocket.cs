﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebSocketSharp;
using SharedLibrary;
using Newtonsoft.Json.Linq;

namespace FinalProjectT3_5
{
    public class ClientChatSocket
    {
        /// <summary>
        /// The WebSocket used to connect to the server
        /// </summary>
        private WebSocket ws;

        /// <summary>
        /// The event triggered when the websocket recieves a message
        /// </summary>
        public event MainForm.OnMessage MessageReceived;

        /// <summary>
        /// A delegate that automatically sends the client back to the IP screen if the server connection dies.
        /// </summary>
        public delegate void NoServer();

        /// <summary>
        /// The physical NoServer delegate
        /// </summary>
        private NoServer _noServer;

        /// <summary>
        /// Initializes the websocket to the given IP, adds an OnMessage event to the websocket, and connects the websocket. Initializes the NoServer delegate.
        /// </summary>
        /// <param name="ip">The IP address the client is attempting to connect to</param>
        /// <param name="ns">The NoServer delegate to be executed when the server connection is dead</param>
        public ClientChatSocket(string ip, NoServer ns)
        {
            ws = new WebSocket("ws://" + ip + ":8001/chat");
            ws.OnMessage += (sender, e) => {MessageReceived?.Invoke(e.Data); };

            ws.Connect();
            _noServer = ns;
        }

        /// <summary>
        /// Sends a message to the server. If the server connection is dead, calls the NoServer delegate
        /// </summary>
        /// <param name="message">The message to send</param>
        public void SendMessage(Message message)
        {
            if (ws.IsAlive)
            {
                ws.Send(JSONizer.ConvertMessageToJSON(message));
            }
            else
            {
                _noServer();
            }
        }

        /// <summary>
        /// Returns whether or not the server connection is alive.
        /// </summary>
        public bool IsAlive
        {
            get
            {
                return ws.IsAlive;
            }
        }
    }
}
