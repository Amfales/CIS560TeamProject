﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedLibrary
{
    public class Account
    {
        List<string> _friends;
        string _passwordHash;
        string _username;

        public Account(string username, string passwordHash)
        {
            _friends = new List<string>();
            _passwordHash = passwordHash;
            _username = username;
        }

        public List<string> Friends
        {
            get
            {
                return _friends;
            }
            set
            {
                _friends = value;
            }
        }

        public string PasswordHash
        {
            get
            {
                return _passwordHash;
            }
        }

        public string Username
        {
            get
            {
                return _username;
            }
        }

        public bool AddFriend(string friend)
        {
            if (!_friends.Contains(friend))
            {
                _friends.Add(friend);
                return true;
            }
            return false;
        }

        public override bool Equals(object o)
        {
            Account other = o as Account;
            if (other == null) return false;
            return (this.Username == other.Username);
        }
    }
}
