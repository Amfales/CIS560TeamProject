﻿namespace FinalProjectT3_5
{
    partial class ChatForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uxChatLabel = new System.Windows.Forms.Label();
            this.uxMutualFriendsLB = new System.Windows.Forms.ListBox();
            this.uxAddToChatBtn = new System.Windows.Forms.Button();
            this.uxSendMessage = new System.Windows.Forms.Button();
            this.uxChattersLB = new System.Windows.Forms.ListBox();
            this.uxMessage = new System.Windows.Forms.TextBox();
            this.uxMutualFriendsLabel = new System.Windows.Forms.Label();
            this.uxCurrentChattersLabel = new System.Windows.Forms.Label();
            this.uxChatBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // uxChatLabel
            // 
            this.uxChatLabel.AutoSize = true;
            this.uxChatLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxChatLabel.Location = new System.Drawing.Point(7, 9);
            this.uxChatLabel.Name = "uxChatLabel";
            this.uxChatLabel.Size = new System.Drawing.Size(65, 25);
            this.uxChatLabel.TabIndex = 0;
            this.uxChatLabel.Text = "Chat:";
            // 
            // uxMutualFriendsLB
            // 
            this.uxMutualFriendsLB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.uxMutualFriendsLB.FormattingEnabled = true;
            this.uxMutualFriendsLB.ItemHeight = 20;
            this.uxMutualFriendsLB.Location = new System.Drawing.Point(751, 181);
            this.uxMutualFriendsLB.Name = "uxMutualFriendsLB";
            this.uxMutualFriendsLB.ScrollAlwaysVisible = true;
            this.uxMutualFriendsLB.Size = new System.Drawing.Size(221, 84);
            this.uxMutualFriendsLB.TabIndex = 2;
            // 
            // uxAddToChatBtn
            // 
            this.uxAddToChatBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.uxAddToChatBtn.Location = new System.Drawing.Point(751, 271);
            this.uxAddToChatBtn.Name = "uxAddToChatBtn";
            this.uxAddToChatBtn.Size = new System.Drawing.Size(221, 31);
            this.uxAddToChatBtn.TabIndex = 3;
            this.uxAddToChatBtn.Text = "Add Friend to Chat";
            this.uxAddToChatBtn.UseVisualStyleBackColor = true;
            this.uxAddToChatBtn.Click += new System.EventHandler(this.uxAddToChatBtn_Click);
            // 
            // uxSendMessage
            // 
            this.uxSendMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.uxSendMessage.Location = new System.Drawing.Point(788, 317);
            this.uxSendMessage.Name = "uxSendMessage";
            this.uxSendMessage.Size = new System.Drawing.Size(184, 30);
            this.uxSendMessage.TabIndex = 4;
            this.uxSendMessage.Text = "Send Message:";
            this.uxSendMessage.UseVisualStyleBackColor = true;
            this.uxSendMessage.Click += new System.EventHandler(this.uxSendMessage_Click);
            // 
            // uxChattersLB
            // 
            this.uxChattersLB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.uxChattersLB.FormattingEnabled = true;
            this.uxChattersLB.ItemHeight = 20;
            this.uxChattersLB.Location = new System.Drawing.Point(751, 58);
            this.uxChattersLB.Name = "uxChattersLB";
            this.uxChattersLB.ScrollAlwaysVisible = true;
            this.uxChattersLB.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.uxChattersLB.Size = new System.Drawing.Size(221, 84);
            this.uxChattersLB.TabIndex = 5;
            // 
            // uxMessage
            // 
            this.uxMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.uxMessage.Location = new System.Drawing.Point(12, 321);
            this.uxMessage.Name = "uxMessage";
            this.uxMessage.Size = new System.Drawing.Size(724, 26);
            this.uxMessage.TabIndex = 1;
            // 
            // uxMutualFriendsLabel
            // 
            this.uxMutualFriendsLabel.AutoSize = true;
            this.uxMutualFriendsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.uxMutualFriendsLabel.Location = new System.Drawing.Point(747, 158);
            this.uxMutualFriendsLabel.Name = "uxMutualFriendsLabel";
            this.uxMutualFriendsLabel.Size = new System.Drawing.Size(118, 20);
            this.uxMutualFriendsLabel.TabIndex = 7;
            this.uxMutualFriendsLabel.Text = "Mutual Friends:";
            // 
            // uxCurrentChattersLabel
            // 
            this.uxCurrentChattersLabel.AutoSize = true;
            this.uxCurrentChattersLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.uxCurrentChattersLabel.Location = new System.Drawing.Point(747, 35);
            this.uxCurrentChattersLabel.Name = "uxCurrentChattersLabel";
            this.uxCurrentChattersLabel.Size = new System.Drawing.Size(131, 20);
            this.uxCurrentChattersLabel.TabIndex = 8;
            this.uxCurrentChattersLabel.Text = "Current Chatters:";
            // 
            // uxChatBox
            // 
            this.uxChatBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.uxChatBox.FormattingEnabled = true;
            this.uxChatBox.HorizontalScrollbar = true;
            this.uxChatBox.ItemHeight = 20;
            this.uxChatBox.Location = new System.Drawing.Point(12, 40);
            this.uxChatBox.Name = "uxChatBox";
            this.uxChatBox.ScrollAlwaysVisible = true;
            this.uxChatBox.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.uxChatBox.Size = new System.Drawing.Size(724, 264);
            this.uxChatBox.TabIndex = 9;
            // 
            // ChatForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 361);
            this.Controls.Add(this.uxChatBox);
            this.Controls.Add(this.uxCurrentChattersLabel);
            this.Controls.Add(this.uxMutualFriendsLabel);
            this.Controls.Add(this.uxMessage);
            this.Controls.Add(this.uxChattersLB);
            this.Controls.Add(this.uxSendMessage);
            this.Controls.Add(this.uxAddToChatBtn);
            this.Controls.Add(this.uxMutualFriendsLB);
            this.Controls.Add(this.uxChatLabel);
            this.Name = "ChatForm";
            this.Text = "Chat";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ChatForm_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label uxChatLabel;
        private System.Windows.Forms.ListBox uxMutualFriendsLB;
        private System.Windows.Forms.Button uxAddToChatBtn;
        private System.Windows.Forms.Button uxSendMessage;
        private System.Windows.Forms.ListBox uxChattersLB;
        private System.Windows.Forms.TextBox uxMessage;
        private System.Windows.Forms.Label uxMutualFriendsLabel;
        private System.Windows.Forms.Label uxCurrentChattersLabel;
        private System.Windows.Forms.ListBox uxChatBox;
    }
}

