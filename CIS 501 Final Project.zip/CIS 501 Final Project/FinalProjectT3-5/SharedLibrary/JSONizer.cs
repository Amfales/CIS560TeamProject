﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Runtime.Serialization;

namespace SharedLibrary
{
    public class JSONizer
    {
        public static string ConvertToJSON(Object o)
        {
            return JsonConvert.SerializeObject(o);
        }

        public static object ConvertToObject(string s)
        {
            return JsonConvert.DeserializeObject(s);
        }

        public static Message ConvertToMessage(string s)
        {
            JsonConverter[] c = new JsonConverter[1];
            c[0] = new Newtonsoft.Json.Converters.StringEnumConverter();
            return JsonConvert.DeserializeObject<Message>(s,c);
        }

        public static string ConvertMessageToJSON(Message m)
        {
            JsonConverter[] c = new JsonConverter[1];
            c[0] = new Newtonsoft.Json.Converters.StringEnumConverter();
            return JsonConvert.SerializeObject(m, c);
        }
    }
}
