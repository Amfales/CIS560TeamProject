﻿/***************************************************************
 * Names: Andrew Fales, Nathan Helgeson, and Grant Willford
 * Due Date: 10/30/17
 * CIS 501 Final Project Server Side
 ***************************************************************
 * This project consists of a simple chat server with options
 * to add and remove contacts, and to chat with those contacts.
 * It uses Websockets to communicate, and the Server side also
 * uses full MVC to allow for communication between the parts,
 * using delegates.
 ***************************************************************
 * This class is the controller of the server side. It serves
 * as both the controller for the ServerForm, and the controller
 * for the actual operations of the server.
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharedLibrary;
using System.Windows.Forms;

namespace FinalProject_Server
{
    public delegate void ServerFormUpdate(List<string> onUsers, List<string> offUsers, List<string> conversations, string message);
    public delegate void ServerFormDispMsg(string message);
    public delegate void Register(ServerFormUpdate u, ServerFormDispMsg m);
    public delegate void HandleServerFormRequest(string userName);
    public delegate void InitServerForm();

    public delegate void OnReceive(string sessId, IMessage m);
    public class Server
    {
        ServerChatSocket _sock;
        ServerFormUpdate _updateServerForm;
        ServerFormDispMsg _messageServerForm;

        UserAccountDB _userDB;
        ConversationDB _convDB;

        Dictionary<string, string> socketIds = new Dictionary<string, string>();

        /// <summary>
        /// Create user information databases and start the WebSocket server
        /// </summary>
        public Server()
        {
            _sock = new ServerChatSocket(DoServerAction);
            _sock.StartServer();
            _userDB = new UserAccountDB();
            _convDB = new ConversationDB();
        }

        /// <summary>
        /// Register the ServerForm delegates
        /// </summary>
        /// <param name="u">ServerForm Update delegate</param>
        /// <param name="m">ServerForm Display Message delegate</param>
        public void Register(ServerFormUpdate u, ServerFormDispMsg m)
        {
            _updateServerForm = u;
            _messageServerForm = m;
        }
        
        /// <summary>
        /// Populate the ServerForm with user information
        /// </summary>
        public void InitializeServerForm()
        {
            Tuple<List<string>, List<string>> userStates = GetUserLists();
            _updateServerForm(userStates.Item1, userStates.Item2, _convDB.GetUserStrings(), null);
        }

        /// <summary>
        /// Send a message to all clients that we're closing the server and then close the WebSocket
        /// server and close the User Database
        /// </summary>
        public void Close()
        {
            foreach (string username in socketIds.Keys)
            {
                _sock.SendMessage(new SharedLibrary.Message(MessageType.ServerFault, new object[] { }), socketIds[username]);
            }

            _sock.StopServer();
            _userDB.Close();
        }
      
        /// <summary>
        /// This method runs for every message that the server recieves. For the given message, depending on the MessageType,
        /// handle the message and send a message response to all clients that must be updated.
        /// </summary>
        /// <param name="sessID">The WebSocket address of the message sender</param>
        /// <param name="msg">The message sent</param>
        public void DoServerAction(string sessID, IMessage msg)
        {
            //serverMessage is the single string that will be added to the serverForm log
            //result is a list of Messages to be sent paired with the WebSocket Id to send the message to
            List<Tuple<string, IMessage>> result = new List<Tuple<string, IMessage>>();
            string serverMessage = null;

            //process a LogInRequest first
            if (msg.TypeOfMessage == MessageType.LogInRequest)
            {
                Tuple<string, List<Tuple<string, IMessage>>> loginResult = DoLogin(sessID, msg, result);
                serverMessage = loginResult.Item1;
                result = loginResult.Item2;
            }

            //after we've checked for a login request, if the person sending the message is offline, something is wrong and we should exit
            if (!_userDB.IsOnline(Convert.ToString(msg.Args[0])))
            {
                if (msg.TypeOfMessage != MessageType.LogInRequest)
                {
                    serverMessage = Convert.ToString(msg.Args[0]) + " tried to do something, but they were offline.";
                }
                //send all of the messages that we have stored to send, update the Server form, and exit
                foreach (Tuple<string, IMessage> pair in result)
                {
                    _sock.SendMessage(pair.Item2, pair.Item1);
                }
                Tuple<List<string>, List<string>> userStates = GetUserLists();
                _updateServerForm(userStates.Item1, userStates.Item2, _convDB.GetUserStrings(), serverMessage);
                return;
            }

            //now, if the message's source is different from the WebSocket address for the user associated with this message, something is wrong, break
            if (sessID != socketIds[Convert.ToString(msg.Args[0])])
            {
                //don't send any of the messages to be sent, becase someone is trying to pose as someone else
                serverMessage = "WARNING! Someone tried to send a message as someone other than themself. Someone may be attacking your server.\nAttempted username: " +
                    Convert.ToString(msg.Args[0]);
                Tuple<List<string>, List<string>> userStates = GetUserLists();
                _updateServerForm(userStates.Item1, userStates.Item2, _convDB.GetUserStrings(), serverMessage);
                return;
            }

            //now for all other message types, call the Method Handler for that message type.
            MessageType type = msg.TypeOfMessage;
            try
            {
                switch (type)
                {
                    case MessageType.AddFriendRequest:
                        {
                            Tuple<string, List<Tuple<string, IMessage>>> addResult = DoAddFriend(msg, result);
                            serverMessage = addResult.Item1;
                            result = addResult.Item2;
                            break;
                        }

                    case MessageType.AddToChatRequest:
                        {
                            Tuple<string, List<Tuple<string, IMessage>>> addResult = DoAddToChat(msg, result);
                            serverMessage = addResult.Item1;
                            result = addResult.Item2;
                            break;
                        }

                    case MessageType.LeaveChatRequst:
                        {
                            Tuple<string, List<Tuple<string, IMessage>>> leaveResult = DoLeaveChat(msg, result);
                            serverMessage = leaveResult.Item1;
                            result = leaveResult.Item2;
                            break;
                        }

                    case MessageType.LogOutRequest:
                        {
                            Tuple<string, List<Tuple<string, IMessage>>> addResult = DoLogout(msg, result);
                            serverMessage = addResult.Item1;
                            result = addResult.Item2;
                            break;
                        }

                    case MessageType.SendChatMessage:
                        {
                            Tuple<string, List<Tuple<string, IMessage>>> sendResult = DoSendChatMessage(msg, result);
                            serverMessage = sendResult.Item1;
                            result = sendResult.Item2;
                            break;
                        }

                    case MessageType.StartChatRequest:
                        {
                            Tuple<string, List<Tuple<string, IMessage>>> startResult = DoStartChatRequest(msg, result);
                            serverMessage = startResult.Item1;
                            result = startResult.Item2;
                            break;
                        }
                    case MessageType.RemoveFriendRequest:
                        {
                            Tuple<string, List<Tuple<string, IMessage>>> removeResult = DoRemoveFriendRequest(msg, result);
                            serverMessage = removeResult.Item1;
                            result = removeResult.Item2;
                            break;
                        }
                }

                //send every message that we've designated to send and then update the ServerForm
                foreach (Tuple<string, IMessage> pair in result)
                {
                    _sock.SendMessage(pair.Item2, pair.Item1);
                }

                Tuple<List<string>, List<string>> userStates = GetUserLists();
                _updateServerForm(userStates.Item1, userStates.Item2, _convDB.GetUserStrings(), serverMessage);
            }
            catch (Exception e)
            {
                _messageServerForm("Message generated an exception:\n" + e.ToString());
            }
        }        

        /// <summary>
        /// Handles a Log In Request
        /// </summary>
        /// <param name="sessId">The WebSocket Address this Log In Request is from</param>
        /// <param name="msg"></param>
        /// <param name="result"></param>
        /// <returns>An updated result Tuple with the new messages to be sent</returns>
        public Tuple<string, List<Tuple<string, IMessage>>> DoLogin(string sessId, IMessage msg, List<Tuple<string, IMessage>> result)
        {
            string username = Convert.ToString(msg.Args[0]);
            string hashedPassword = Convert.ToString(msg.Args[1]);
            string servermessage = null;

            //if the attempted username already exists, try to log them in. Else, create a new account for them.
            if (_userDB.ContainsAccount(username))
            {
                Account acc = _userDB.GetAccount(username);
                //if the user is already registered as logged in to the server, don't allow them to log in again.
                if (_userDB.IsOnline(username))
                {
                    result.Add(new Tuple<string, IMessage>(sessId, new SharedLibrary.Message(MessageType.LogInResponse, new object[] { null })));
                    servermessage = username + " attempted to log in, but was already logged in somewhere else.";
                }
                //check if the user entered the right password
                else if (hashedPassword == acc.PasswordHash)
                {
                    //if the user had the right password, tell all of the user's friends and all of their conversations that the user is coming online.
                    socketIds.Add(username, sessId);
                    List<string> updateAccounts = _userDB.SetOnline(acc);
                    HashSet<Conversation> toUpdate = new HashSet<Conversation>();
                    //update friends' Online Friends
                    foreach (string user in updateAccounts)
                    {
                        foreach (Conversation c in _convDB.GetUserConversations(user)) toUpdate.Add(c);
                        result.Add(new Tuple<string, IMessage>(socketIds[user], new SharedLibrary.Message(MessageType.UpdateAccount, new object[] { _userDB.GetOnlineAccount(user), user })));
                    }
                    //update friends' conversation mutual friends
                    foreach (Conversation c in toUpdate)
                    {
                        c.MutualFriends = MakeNewMutualFriends(c);
                        foreach (string u in c.Users)
                        {
                            result.Add(new Tuple<string, IMessage>(socketIds[u], new SharedLibrary.Message(MessageType.UpdateConversation, new object[] { c, c.uID })));
                        }
                    }
                    result.Add(new Tuple<string, IMessage>(sessId, new SharedLibrary.Message(MessageType.LogInResponse, new object[] { _userDB.GetOnlineAccount(username) })));
                    servermessage = username + " successfully logged in.";
                }
                else
                {
                    //the password was wrong, tell the user they had a bad password
                    result.Add(new Tuple<string, IMessage>(sessId, new SharedLibrary.Message(MessageType.LogInResponse, new object[] { null })));
                    servermessage = username + " attempted to log in with a bad password.";
                }
            }
            else
            {
                //add an account for this new username
                socketIds.Add(username, sessId);
                Account temp = new Account(username, hashedPassword);
                _userDB.AddAccount(temp);
                _userDB.SetOnline(temp);
                result.Add(new Tuple<string, IMessage>(sessId, new SharedLibrary.Message(MessageType.LogInResponse, new object[] { _userDB.GetOnlineAccount(username) })));
                servermessage = "New user account created for " + username;
            }

            return new Tuple<string, List<Tuple<string, IMessage>>>(servermessage, result);
        }

        /// <summary>
        /// Handle a Add Friend Request message
        /// </summary>
        /// <param name="msg">The sent message</param>
        /// <param name="result">The messages to be sent, paired with the server message</param>
        /// <returns>An updated result Tuple with the new messages to be sent</returns>
        public Tuple<string, List<Tuple<string, IMessage>>> DoAddFriend(IMessage msg, List<Tuple<string, IMessage>> result)
        {
            string serverMessage = null;
            string origUser = Convert.ToString(msg.Args[0]);
            string otherUser = Convert.ToString(msg.Args[1]);
            
            //check if the name the user entered is a valid username
            if (!_userDB.ContainsAccount(otherUser))
            {
                serverMessage = origUser + " tried to add " + otherUser + " as a friend, but " + otherUser + " wasn't a valid account.";
                result.Add(new Tuple<string, IMessage>(socketIds[origUser], new SharedLibrary.Message(MessageType.UpdateAccount, new object[] { null })));
            }
            //try to add this person as a friend. If AddFriend returns false, then otherUser was already on their friends list
            else if (!_userDB.GetAccount(origUser).AddFriend(otherUser))
            {
                serverMessage = origUser + " tried to add " + otherUser + " as a friend, but " + otherUser + " was already on their list.";
                result.Add(new Tuple<string, IMessage>(socketIds[origUser], new SharedLibrary.Message(MessageType.UpdateAccount, new object[] { null })));
            }
            else
            {
                //add this account as a friend
                serverMessage = origUser + " added " + otherUser + " as a friend.";
                _userDB.GetOnlineAccount(origUser).AddFriend(otherUser);
                if (_userDB.IsOnline(otherUser))
                {
                    _userDB.GetOnlineAccount(origUser).AddOnlineFriend(otherUser);
                    //update conversations' mutualfriends
                    foreach (Conversation c in _convDB.GetUserConversations(origUser))
                    {
                        c.MutualFriends = MakeNewMutualFriends(c);
                        foreach (string uName in c.Users)
                        {
                            result.Add(new Tuple<string, IMessage>(socketIds[uName], new SharedLibrary.Message(MessageType.UpdateConversation, new object[] { c, c.uID })));
                        }
                    }
                }
                result.Add(new Tuple<string, IMessage>(socketIds[origUser], new SharedLibrary.Message(MessageType.UpdateAccount, new object[] { _userDB.GetOnlineAccount(origUser) })));
            }
            return new Tuple<string, List<Tuple<string, IMessage>>>(serverMessage, result);
        }

        /// <summary>
        /// Handle a Add To Chat Request message
        /// </summary>
        /// <param name="msg">The sent message</param>
        /// <param name="result">The messages to be sent, paired with the server message</param>
        /// <returns>An updated result Tuple with the new messages to be sent</returns>
        public Tuple<string, List<Tuple<string, IMessage>>> DoAddToChat(IMessage msg, List<Tuple<string, IMessage>> result)
        {
            string serverMessage = null;
            string requestor = Convert.ToString(msg.Args[0]);
            string username = Convert.ToString(msg.Args[1]);
            //check that the user is online
            if (_userDB.IsOnline(username))
            {
                //add the user to the chat - add a line to the conversation that this user joined and then tell everyone in
                //the conversation that this user is being added
                int chatID = Convert.ToInt32(msg.Args[2]);
                Conversation c = _convDB.Get(chatID);
                c.AddUser(_userDB.GetOnlineAccount(username));
                _userDB.GetOnlineAccount(username).AddConversation(c.uID);
                string notification = GetTime() + " " + username + " has joined the conversation.";
                c.AddLine(notification);
                result.Add(new Tuple<string, IMessage>(socketIds[username], new SharedLibrary.Message(MessageType.StartChatResponse, new object[] { c, c.uID })));
                foreach (string user in c.Users)
                {
                    if (user == username) continue;
                    result.Add(new Tuple<string, IMessage>(socketIds[user], new SharedLibrary.Message(MessageType.UpdateConversation, new object[] { c, c.uID })));
                }
                serverMessage = username + " was added to the group message of " + c.UserString(username);
            }
            else
            {
                serverMessage = "Someone tried to add " + username + " to their conversation, but " + username + " is offline.";
            }
            return new Tuple<string, List<Tuple<string, IMessage>>>(serverMessage, result);
        }

        /// <summary>
        /// Handles a Leave Chat Message
        /// </summary>
        /// <param name="msg">The sent message</param>
        /// <param name="result">The messages to be sent, paired with the server message</param>
        /// <returns>An updated result Tuple with the new messages to be sent</returns>
        public Tuple<string, List<Tuple<string, IMessage>>> DoLeaveChat(IMessage msg, List<Tuple<string, IMessage>> result)
        {
            string serverMessage = null;
            string username = Convert.ToString(msg.Args[0]);
            int chatID = Convert.ToInt32(msg.Args[1]);

            Conversation c = _convDB.Get(chatID);
            //so long as the passed conversationID was valid
            if (c != null)
            {
                //remove this user from the conversation
                c.DeleteUser(_userDB.GetAccount(username));
                if (c.Users.Count < 2)
                {
                    //if only one person is left in the conversation, close their chat window
                    _convDB.RemoveConv(c.uID);
                    foreach (string uName in c.Users)
                    {
                        result.Add(new Tuple<string, IMessage>(socketIds[uName], new SharedLibrary.Message(MessageType.UpdateConversation, new object[] { null, c.uID })));
                    }
                    string otherusername = c.Users[0];
                    serverMessage = username + " has left their conversation with " + c.Users[0] + ". The conversation has been closed.";
                }
                else
                {
                    //if people are left in the conversation, tell them all that this user has left the conversation
                    c.AddLine(GetTime() + " " + username + " has left the conversation");
                    c.MutualFriends = MakeNewMutualFriends(c);
                    foreach (string uName in c.Users)
                    {
                        result.Add(new Tuple<string, IMessage>(socketIds[uName], new SharedLibrary.Message(MessageType.UpdateConversation, new object[] { c, c.uID })));
                    }
                    serverMessage = username + " left the conversation of: " + c.UserString(username);
                }
            }
            return new Tuple<string, List<Tuple<string, IMessage>>>(serverMessage, result);
        }

        /// <summary>
        /// Handles a Log Out Request
        /// </summary>
        /// <param name="msg">The sent message</param>
        /// <param name="result">The messages to be sent, paired with the server message</param>
        /// <returns>An updated result Tuple with the new messages to be sent</returns>
        public Tuple<string, List<Tuple<string, IMessage>>> DoLogout(IMessage msg, List<Tuple<string, IMessage>> result)
        {
            string serverMessage = null;
            string username = Convert.ToString(msg.Args[0]);
            Account acc = _userDB.GetAccount(username);        

            HashSet<Conversation> toUpdate = new HashSet<Conversation>();
            //tell each of our online friends that we are logging off
            foreach (string user in _userDB.GetOnlineAccount(username).OnlineFriends)
            {
                foreach (Conversation c in _convDB.GetUserConversations(user)) toUpdate.Add(c);
                result.Add(new Tuple<string, IMessage>(socketIds[user], new SharedLibrary.Message(MessageType.UpdateAccount, new object[] { _userDB.GetOnlineAccount(user), user })));
            }
            
            //update all of our open conversations that we are leaving the conversation (and leave the conversation)
            foreach (Conversation c in _convDB.GetUserConversations(username))
            {
                toUpdate.Add(c);
                c.DeleteUser(_userDB.GetAccount(username));
                if (c.Users.Count < 2)
                {
                    _convDB.RemoveConv(c.uID);
                    foreach (string uName in c.Users)
                    {
                        result.Add(new Tuple<string, IMessage>(socketIds[uName], new SharedLibrary.Message(MessageType.UpdateConversation, new object[] { null, c.uID })));
                    }
                }
                else
                {
                    c.AddLine(GetTime() + " " + username + " has left the conversation");
                    c.MutualFriends = MakeNewMutualFriends(c);
                    foreach (string uName in c.Users)
                    {
                        result.Add(new Tuple<string, IMessage>(socketIds[uName], new SharedLibrary.Message(MessageType.UpdateConversation, new object[] { c, c.uID })));
                    }
                }
            }            

            //SetOffline returns a list of users that we need to update we are going offline
            List<string> updateAccounts = _userDB.SetOffline(acc);
            foreach (string user in updateAccounts)
            {
                result.Add(new Tuple<string, IMessage>(socketIds[user], new SharedLibrary.Message(MessageType.UpdateAccount, new object[] { _userDB.GetOnlineAccount(user), user })));
            }

            //tell each person that we have saved that we are leaving their conversation
            foreach (Conversation c in toUpdate)
            {
                c.MutualFriends = MakeNewMutualFriends(c);
                foreach (string u in c.Users)
                {
                    result.Add(new Tuple<string, IMessage>(socketIds[u], new SharedLibrary.Message(MessageType.UpdateConversation, new object[] { c, c.uID })));
                }
            }

            //release our socket address for this username
            socketIds.Remove(username);
            serverMessage = username + " logged out.";
            return new Tuple<string, List<Tuple<string, IMessage>>>(serverMessage, result);
        }

        /// <summary>
        /// Handles A Sent Chat Message
        /// </summary>
        /// <param name="msg">The sent message</param>
        /// <param name="result">The messages to be sent, paired with the server message</param>
        /// <returns>An updated result Tuple with the new messages to be sent</returns>
        public Tuple<string, List<Tuple<string, IMessage>>> DoSendChatMessage(IMessage msg, List<Tuple<string, IMessage>> result)
        {
            string serverMessage = null;
            string username = Convert.ToString(msg.Args[0]);
            int chatID = Convert.ToInt32(msg.Args[1]);
            string rawmsg = Convert.ToString(msg.Args[2]);
            Conversation c = _convDB.Get(chatID);
            //format the passed message to include the current time and the username
            string formatMsg = GetTime() + " " + username + ": " + rawmsg;
            c.AddLine(formatMsg);
            //send the formatted message to everyone in this conversation
            foreach (string user in c.Users)
            {
                result.Add(new Tuple<string, IMessage>(socketIds[user], new SharedLibrary.Message(MessageType.RecieveChatMessage, new object[] { chatID, formatMsg })));
            }
            serverMessage = username + " sent a message to: " + c.UserString(username);
            return new Tuple<string, List<Tuple<string, IMessage>>>(serverMessage, result);
        }

        /// <summary>
        /// Handles a start chat request
        /// </summary>
        /// <param name="msg">The sent message</param>
        /// <param name="result">The messages to be sent, paired with the server message</param>
        /// <returns>An updated result Tuple with the new messages to be sent</returns>
        public Tuple<string, List<Tuple<string, IMessage>>> DoStartChatRequest(IMessage msg, List<Tuple<string, IMessage>> result)
        {
            string serverMessage = null;
            string origUser = Convert.ToString(msg.Args[0]);
            string otherUser = Convert.ToString(msg.Args[1]);
            //as long as both users are online
            if (_userDB.IsOnline(origUser) && _userDB.IsOnline(otherUser))
            {
                //and they both are friends with each other
                if (_userDB.GetAccount(origUser).Friends.Contains(otherUser)
                    && _userDB.GetAccount(otherUser).Friends.Contains(origUser))
                {
                    //start the conversation, add both users and tell them the conversation started
                    int convID = _convDB.AddConversation(_userDB.GetOnlineAccount(origUser), _userDB.GetOnlineAccount(otherUser));
                    _userDB.GetOnlineAccount(origUser).AddConversation(convID);
                    _userDB.GetOnlineAccount(otherUser).AddConversation(convID);
                    result.Add(new Tuple<string, IMessage>(socketIds[origUser], new SharedLibrary.Message(MessageType.StartChatResponse, new object[] { _convDB.Get(convID), convID })));
                    result.Add(new Tuple<string, IMessage>(socketIds[otherUser], new SharedLibrary.Message(MessageType.StartChatResponse, new object[] { _convDB.Get(convID), convID })));
                    serverMessage = origUser + " started a conversation with " + otherUser;
                }
                else
                {
                    //the users weren't both friends with each other
                    result.Add(new Tuple<string, IMessage>(socketIds[origUser], new SharedLibrary.Message(MessageType.StartChatResponse, new object[] { null, -1 })));
                    serverMessage = origUser + " tried to start a conversation with " + otherUser + ", but they weren't mutual friends.";
                }
            }
            else
            {
                //at least one of the users was offline
                result.Add(new Tuple<string, IMessage>(socketIds[origUser], new SharedLibrary.Message(MessageType.StartChatResponse, new object[] { null, -1 })));
                serverMessage = origUser + " tried to start a conversation with " + otherUser + ", but " + otherUser + " was offline.";
            }
            return new Tuple<string, List<Tuple<string, IMessage>>>(serverMessage, result);
        }

        /// <summary>
        /// Handles a Remove Friend Request
        /// </summary>
        /// <param name="msg">The sent message</param>
        /// <param name="result">The messages to be sent, paired with the server message</param>
        /// <returns>An updated result Tuple with the new messages to be sent</returns>
        public Tuple<string, List<Tuple<string, IMessage>>> DoRemoveFriendRequest(IMessage msg, List<Tuple<string, IMessage>> result)
        {
            string serverMessage = null;
            string origUser = Convert.ToString(msg.Args[0]);
            string otherUser = Convert.ToString(msg.Args[1]);
            bool shouldRemove = true;
            string toSend = "Could not remove friend.";
            
            //if the user to remove is not a valid account, do nothing and warn the user that this person was not on their friends list
            if (!_userDB.ContainsAccount(otherUser))
            {
                shouldRemove = false;
                toSend = "Could not remove friend. " + otherUser + " is not on your friends list!";
            }
            //as long as we haven't hit an error yet...
            if (shouldRemove)
            {
                //if the user exists, but is not on this user's friend list, do nothing and warn the user that this person was not on their friends list
                if (!_userDB.GetAccount(origUser).Friends.Contains(otherUser))
                {
                    shouldRemove = false;
                    toSend = "Could not remove friend. " + otherUser + " is not on your friends list!";
                }
                //as long as we haven't hit an error yet...
                if (shouldRemove)
                {
                    //make sure that this user has no open conversations with the person they are going to remove
                    //(removing the second user from a group chat because someone unfriended them seems unfair)
                    if (_userDB.IsOnline(otherUser))
                    {
                        foreach (Conversation c in _convDB.GetUserConversations(origUser))
                        {
                            if (c.Users.Contains(otherUser))
                            {
                                shouldRemove = false;
                                toSend = "Could not remove friend. You must exit all your open conversations with " + otherUser + " before you can remove them.";
                            }
                        }
                    }
                }
            }
            //as long as something hasn't gone wrong
            if (shouldRemove)
            {
                //remove the user from the requestor's friend lists
                if (_userDB.IsOnline(otherUser))
                {
                    _userDB.GetOnlineAccount(origUser).OnlineFriends.Remove(otherUser);
                }
                _userDB.GetOnlineAccount(origUser).Friends.Remove(otherUser);

                //notify the user that this happened
                result.Add(new Tuple<string, IMessage>(socketIds[origUser], new SharedLibrary.Message(MessageType.UpdateAccount, new object[] { _userDB.GetOnlineAccount(origUser) })));
                serverMessage = origUser + " removed " + otherUser + " as a friend.";
            }
            else
            {
                result.Add(new Tuple<string, IMessage>(socketIds[origUser], new SharedLibrary.Message(MessageType.RemoveFriendResponse, new object[] { toSend })));
            }

            return new Tuple<string, List<Tuple<string, IMessage>>>(serverMessage, result);
        }

        /// <summary>
        /// Runs when the ServerForm requests information on a user. Creates a string of the user's information and
        /// sends it with MessageServerForm
        /// </summary>
        /// <param name="userName">The username we want information on</param>
        public void HandleServerFormRequest(string userName)
        {
            StringBuilder result = new StringBuilder();
            result.Append("Username: " + userName + "\n");
            result.Append((_userDB.IsOnline(userName)) ? "Online\n" : "Offline\n");
            result.Append("Contacts:");
            foreach (string friend in _userDB.GetAccount(userName).Friends)
            {
                result.Append("\n" + friend);
            }
            if (_userDB.IsOnline(userName))
            {
                result.Append("\n\nChats:");
                foreach (Conversation conv in _convDB.GetUserConversations(userName))
                {
                    result.Append("\n");
                    result.Append(conv.UserString(userName));                 
                }
            }
            else
            {
                result.Append("\n\nUser offline, no chats available.");
            }
            _messageServerForm(result.ToString());
        }

        /// <summary>
        /// Return the current time formatted as "HH:MM AM/PM"
        /// </summary>
        /// <returns>The formatted time</returns>
        private string GetTime()
        {
            return DateTime.Now.ToString("hh:mm tt");
        }

        /// <summary>
        /// Returns two lists - online users and offline users
        /// </summary>
        /// <returns>Tuple of list of online users and list of offline users</returns>
        private Tuple<List<string>, List<string>> GetUserLists()
        {
            List<string> online = new List<string>();
            List<string> offline = new List<string>();
            foreach (Account user in _userDB.Accounts)
            {
                if (_userDB.IsOnline(user.Username)) online.Add(user.Username);
                else offline.Add(user.Username);
            }
            return new Tuple<List<string>, List<string>>(online, offline);
        }


        /// <summary>
        /// Rebuilds the list of online mututal friends that can be added to a conversation
        /// </summary>
        /// <param name="c">The conversation to update</param>
        /// <returns>An updated list of mutual friends</returns>
        private List<string> MakeNewMutualFriends(Conversation c)
        {
            List<string> newMutual = new List<string>(_userDB.GetOnlineAccount(c.Users[0]).OnlineFriends.Where(friend => _userDB.GetOnlineAccount(friend).OnlineFriends.Contains(c.Users[0])));
            for (int i = 1; i < c.Users.Count; i++)
            {
                List<string> thisFriends = _userDB.GetOnlineAccount(c.Users[i]).OnlineFriends;
                newMutual = newMutual.Intersect(thisFriends.Where(friend => _userDB.GetOnlineAccount(friend).OnlineFriends.Contains(c.Users[i]))).ToList<string>();
            }
            return newMutual;
        }
    }
}
