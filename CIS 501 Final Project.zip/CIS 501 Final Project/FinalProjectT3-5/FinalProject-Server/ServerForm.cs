﻿/***************************************************************
 * Names: Andrew Fales, Nathan Helgeson, and Grant Willford
 * Due Date: 10/30/17
 * CIS 501 Final Project Server Side
 ***************************************************************
 * This project consists of a simple chat server with options
 * to add and remove contacts, and to chat with those contacts.
 * It uses Websockets to communicate, and the Server side also
 * uses full MVC to allow for communication between the parts,
 * using delegates.
 ***************************************************************
 * This class is the view part of the server side of the final
 * project. It updates to reflect everything that is happening
 * in the server, and allows us to check what information is
 * available on the accounts in the server.
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;

namespace FinalProject_Server
{
    public partial class ServerForm : Form
    {
        private HandleServerFormRequest _han;
        /// <summary>
        /// This is the constructor, it stores or uses the delegates as necessary,
        /// and initializes the form.
        /// </summary>
        /// <param name="han">The HandleServerFormRequest delegate from the controller.</param>
        /// <param name="reg">The Register delegate from the controller.</param>
        /// <param name="init">The InitServerForm delegate from the controller.</param>
        public ServerForm(HandleServerFormRequest han, Register reg,InitServerForm init)
        {
            InitializeComponent();
            _han = han;
            reg(UpdateForm, DisplayInfo);
            uxServInfoBox.Text = "";
            this.Load += (sender,e) => { init(); } ;
            this.Text += " - " + Dns.GetHostByName(Dns.GetHostName()).AddressList[Dns.GetHostByName(Dns.GetHostName()).AddressList.Length-1].ToString();
        }
        /// <summary>
        /// This method updates the form with the given information. It is
        /// an implementation of the ServerFormUpdate delegate, that the 
        /// Controller calls whenever something happens, that the server
        /// form needs to be updated to display.
        /// </summary>
        /// <param name="onUsers">A list of the usernames of all online users.</param>
        /// <param name="offUsers">A list of the usernames of all offline users.</param>
        /// <param name="convos">A list of the users in all current conversations.</param>
        /// <param name="message">The event that the server has just processed, to be displayed as the most recent action.</param>
        private void UpdateForm(List<string> onUsers, List<string> offUsers, List<string> convos, string message)
        {
            //The Invoke call below is necessary for changing anything on the form, due to weird threading stuff.
            Invoke(new Action(() =>
            {
                if (onUsers.Count > 0 || offUsers.Count > 0)//The GetUserInfo can only do anything if there are already users.
                {
                    uxGetUserInfo.Enabled = true;
                }
                else
                {
                    uxGetUserInfo.Enabled = false;
                }
                uxOnlineBox.DataSource = onUsers;
                uxOfflineBox.DataSource = offUsers;
                uxConvoBox.DataSource = convos;
                if (message == null) return;

                if (uxServInfoBox.Text != "")//Don't append a new line for the first action handled by the server.
                {
                    uxServInfoBox.AppendText("\r\n" + message);
                }
                else
                {
                    uxServInfoBox.Text = message;
                }
            }));
        }
        /// <summary>
        /// This method takes whatever string it is given and displays it in a messagebox.
        /// It is the interface of type ServerFormDispMsg, and is passed to the controller (server).
        /// </summary>
        /// <param name="message"></param>
        private void DisplayInfo(string message)
        {
            MessageBox.Show(message);
        }
        /// <summary>
        /// This is used so that you will only have one user selected before clicking the button
        /// for getting user info.
        /// </summary>
        /// <param name="sender">The object that sent the event.</param>
        /// <param name="e">The arguments the event was sent with.</param>
        private void uxOnlineBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (uxOnlineBox.SelectedValue != null)
            uxOfflineBox.ClearSelected();
        }
        /// <summary>
        /// This is used so that you will only have one user selected before clicking the button
        /// for getting user info.
        /// </summary>
        /// <param name="sender">The object that sent the event.</param>
        /// <param name="e">The arguments the event was sent with.</param>
        private void uxOfflineBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (uxOfflineBox.SelectedValue != null)
            {
                uxOnlineBox.ClearSelected();
            }
            
        }
        /// <summary>
        /// This is the button click event that gets the username that
        /// was selected in the Listbox, and then sends the username to
        /// the controller to processthe data. If nothing is selected,
        /// it calls the DisplayInfo method to say that no user was
        /// selected.
        /// </summary>
        /// <param name="sender">The object that sent the event.</param>
        /// <param name="e">The arguments the event was sent with.</param>
        private void uxGetUserInfo_Click(object sender, EventArgs e)
        {
            if (uxOnlineBox.SelectedValue != null)
            {
                _han(uxOnlineBox.SelectedValue as string);
            }
            else if (uxOfflineBox.SelectedValue != null)
            {
                _han(uxOfflineBox.SelectedValue as string);
            }
            else
            {
                DisplayInfo("Error, you have not selected a user.");
            }
        }
    }
}
