﻿/***************************************************************
 * Names: Andrew Fales, Nathan Helgeson, and Grant Willford
 * Due Date: 10/30/17
 * CIS 501 Final Project Server Side
 ***************************************************************
 * This project consists of a simple chat server with options
 * to add and remove contacts, and to chat with those contacts.
 * It uses Websockets to communicate, and the Server side also
 * uses full MVC to allow for communication between the parts,
 * using delegates.
 ***************************************************************
 * This class is the Program.cs that actually launches the
 * Server and the ServerForm. It hands them whatever delegates
 * it needs, as necessary.
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject_Server
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application. Initializes everything that it needs to.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Server s = new Server();
          
            ServerForm sf = new ServerForm(s.HandleServerFormRequest, s.Register, s.InitializeServerForm);
            Application.Run(sf);
            s.Close();
        }
    }
}
