﻿namespace FinalProjectT3_5
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uxLoginLabel = new System.Windows.Forms.Label();
            this.uxLogInBtn = new System.Windows.Forms.Button();
            this.uxUsername = new System.Windows.Forms.TextBox();
            this.uxPassword = new System.Windows.Forms.TextBox();
            this.uxUsernameLabel = new System.Windows.Forms.Label();
            this.uxPasswordLabel = new System.Windows.Forms.Label();
            this.uxLoginGB = new System.Windows.Forms.GroupBox();
            this.uxIPgb = new System.Windows.Forms.GroupBox();
            this.uxIPbtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.uxIP = new System.Windows.Forms.TextBox();
            this.uxMainGB = new System.Windows.Forms.GroupBox();
            this.uxLogoutBtn = new System.Windows.Forms.Button();
            this.uxContactsLabel = new System.Windows.Forms.Label();
            this.uxOnlineContactsLabel = new System.Windows.Forms.Label();
            this.uxContactLB = new System.Windows.Forms.ListBox();
            this.uxAddContactBtn = new System.Windows.Forms.Button();
            this.uxUsernameMainLabel = new System.Windows.Forms.Label();
            this.uxAddUsername = new System.Windows.Forms.TextBox();
            this.uxLoggedInLB = new System.Windows.Forms.ListBox();
            this.uxAccountLabel = new System.Windows.Forms.Label();
            this.uxStartChatBtn = new System.Windows.Forms.Button();
            this.uxRemoveContact = new System.Windows.Forms.Button();
            this.uxLoginGB.SuspendLayout();
            this.uxIPgb.SuspendLayout();
            this.uxMainGB.SuspendLayout();
            this.SuspendLayout();
            // 
            // uxLoginLabel
            // 
            this.uxLoginLabel.AutoSize = true;
            this.uxLoginLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.uxLoginLabel.Location = new System.Drawing.Point(263, 103);
            this.uxLoginLabel.Name = "uxLoginLabel";
            this.uxLoginLabel.Size = new System.Drawing.Size(194, 31);
            this.uxLoginLabel.TabIndex = 0;
            this.uxLoginLabel.Text = "Account Login:";
            // 
            // uxLogInBtn
            // 
            this.uxLogInBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.uxLogInBtn.Location = new System.Drawing.Point(289, 241);
            this.uxLogInBtn.Name = "uxLogInBtn";
            this.uxLogInBtn.Size = new System.Drawing.Size(143, 46);
            this.uxLogInBtn.TabIndex = 1;
            this.uxLogInBtn.Text = "Log In";
            this.uxLogInBtn.UseVisualStyleBackColor = true;
            this.uxLogInBtn.Click += new System.EventHandler(this.uxLogInBtn_Click);
            // 
            // uxUsername
            // 
            this.uxUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.uxUsername.Location = new System.Drawing.Point(336, 152);
            this.uxUsername.Name = "uxUsername";
            this.uxUsername.Size = new System.Drawing.Size(162, 30);
            this.uxUsername.TabIndex = 2;
            // 
            // uxPassword
            // 
            this.uxPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.uxPassword.Location = new System.Drawing.Point(336, 196);
            this.uxPassword.Name = "uxPassword";
            this.uxPassword.PasswordChar = '*';
            this.uxPassword.Size = new System.Drawing.Size(162, 30);
            this.uxPassword.TabIndex = 3;
            // 
            // uxUsernameLabel
            // 
            this.uxUsernameLabel.AutoSize = true;
            this.uxUsernameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.uxUsernameLabel.Location = new System.Drawing.Point(222, 155);
            this.uxUsernameLabel.Name = "uxUsernameLabel";
            this.uxUsernameLabel.Size = new System.Drawing.Size(108, 25);
            this.uxUsernameLabel.TabIndex = 5;
            this.uxUsernameLabel.Text = "Username:";
            // 
            // uxPasswordLabel
            // 
            this.uxPasswordLabel.AutoSize = true;
            this.uxPasswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.uxPasswordLabel.Location = new System.Drawing.Point(222, 199);
            this.uxPasswordLabel.Name = "uxPasswordLabel";
            this.uxPasswordLabel.Size = new System.Drawing.Size(104, 25);
            this.uxPasswordLabel.TabIndex = 6;
            this.uxPasswordLabel.Text = "Password:";
            // 
            // uxLoginGB
            // 
            this.uxLoginGB.Controls.Add(this.uxLoginLabel);
            this.uxLoginGB.Controls.Add(this.uxPasswordLabel);
            this.uxLoginGB.Controls.Add(this.uxLogInBtn);
            this.uxLoginGB.Controls.Add(this.uxUsernameLabel);
            this.uxLoginGB.Controls.Add(this.uxUsername);
            this.uxLoginGB.Controls.Add(this.uxPassword);
            this.uxLoginGB.Location = new System.Drawing.Point(6, 11);
            this.uxLoginGB.Name = "uxLoginGB";
            this.uxLoginGB.Size = new System.Drawing.Size(736, 391);
            this.uxLoginGB.TabIndex = 7;
            this.uxLoginGB.TabStop = false;
            // 
            // uxIPgb
            // 
            this.uxIPgb.Controls.Add(this.uxIPbtn);
            this.uxIPgb.Controls.Add(this.label1);
            this.uxIPgb.Controls.Add(this.uxIP);
            this.uxIPgb.Location = new System.Drawing.Point(6, 10);
            this.uxIPgb.Margin = new System.Windows.Forms.Padding(1);
            this.uxIPgb.Name = "uxIPgb";
            this.uxIPgb.Padding = new System.Windows.Forms.Padding(1);
            this.uxIPgb.Size = new System.Drawing.Size(736, 395);
            this.uxIPgb.TabIndex = 7;
            this.uxIPgb.TabStop = false;
            this.uxIPgb.Text = "IP";
            // 
            // uxIPbtn
            // 
            this.uxIPbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.uxIPbtn.Location = new System.Drawing.Point(295, 202);
            this.uxIPbtn.Margin = new System.Windows.Forms.Padding(1);
            this.uxIPbtn.Name = "uxIPbtn";
            this.uxIPbtn.Size = new System.Drawing.Size(147, 63);
            this.uxIPbtn.TabIndex = 2;
            this.uxIPbtn.Text = "Check IP";
            this.uxIPbtn.UseVisualStyleBackColor = true;
            this.uxIPbtn.Click += new System.EventHandler(this.uxIPbtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label1.Location = new System.Drawing.Point(329, 130);
            this.label1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter IP:";
            // 
            // uxIP
            // 
            this.uxIP.Location = new System.Drawing.Point(295, 167);
            this.uxIP.Margin = new System.Windows.Forms.Padding(1);
            this.uxIP.Name = "uxIP";
            this.uxIP.Size = new System.Drawing.Size(147, 20);
            this.uxIP.TabIndex = 0;
            this.uxIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // uxMainGB
            // 
            this.uxMainGB.Controls.Add(this.uxLogoutBtn);
            this.uxMainGB.Controls.Add(this.uxContactsLabel);
            this.uxMainGB.Controls.Add(this.uxOnlineContactsLabel);
            this.uxMainGB.Controls.Add(this.uxContactLB);
            this.uxMainGB.Controls.Add(this.uxAddContactBtn);
            this.uxMainGB.Controls.Add(this.uxUsernameMainLabel);
            this.uxMainGB.Controls.Add(this.uxAddUsername);
            this.uxMainGB.Controls.Add(this.uxLoggedInLB);
            this.uxMainGB.Controls.Add(this.uxAccountLabel);
            this.uxMainGB.Controls.Add(this.uxStartChatBtn);
            this.uxMainGB.Controls.Add(this.uxRemoveContact);
            this.uxMainGB.Location = new System.Drawing.Point(14, 10);
            this.uxMainGB.Name = "uxMainGB";
            this.uxMainGB.Size = new System.Drawing.Size(720, 395);
            this.uxMainGB.TabIndex = 8;
            this.uxMainGB.TabStop = false;
            // 
            // uxLogoutBtn
            // 
            this.uxLogoutBtn.Location = new System.Drawing.Point(661, 10);
            this.uxLogoutBtn.Name = "uxLogoutBtn";
            this.uxLogoutBtn.Size = new System.Drawing.Size(53, 23);
            this.uxLogoutBtn.TabIndex = 16;
            this.uxLogoutBtn.Text = "Logout";
            this.uxLogoutBtn.UseVisualStyleBackColor = true;
            this.uxLogoutBtn.Click += new System.EventHandler(this.uxLogoutBtn_Click);
            // 
            // uxContactsLabel
            // 
            this.uxContactsLabel.AutoSize = true;
            this.uxContactsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.uxContactsLabel.Location = new System.Drawing.Point(390, 47);
            this.uxContactsLabel.Name = "uxContactsLabel";
            this.uxContactsLabel.Size = new System.Drawing.Size(157, 25);
            this.uxContactsLabel.TabIndex = 15;
            this.uxContactsLabel.Text = "Offline Contacts:";
            // 
            // uxOnlineContactsLabel
            // 
            this.uxOnlineContactsLabel.AutoSize = true;
            this.uxOnlineContactsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.uxOnlineContactsLabel.Location = new System.Drawing.Point(-1, 47);
            this.uxOnlineContactsLabel.Name = "uxOnlineContactsLabel";
            this.uxOnlineContactsLabel.Size = new System.Drawing.Size(158, 25);
            this.uxOnlineContactsLabel.TabIndex = 14;
            this.uxOnlineContactsLabel.Text = "Online Contacts:";
            // 
            // uxContactLB
            // 
            this.uxContactLB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.uxContactLB.FormattingEnabled = true;
            this.uxContactLB.ItemHeight = 25;
            this.uxContactLB.Location = new System.Drawing.Point(395, 76);
            this.uxContactLB.Name = "uxContactLB";
            this.uxContactLB.ScrollAlwaysVisible = true;
            this.uxContactLB.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.uxContactLB.Size = new System.Drawing.Size(315, 204);
            this.uxContactLB.TabIndex = 12;
            // 
            // uxAddContactBtn
            // 
            this.uxAddContactBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.uxAddContactBtn.Location = new System.Drawing.Point(395, 333);
            this.uxAddContactBtn.Name = "uxAddContactBtn";
            this.uxAddContactBtn.Size = new System.Drawing.Size(144, 50);
            this.uxAddContactBtn.TabIndex = 9;
            this.uxAddContactBtn.Text = "Add";
            this.uxAddContactBtn.UseVisualStyleBackColor = true;
            this.uxAddContactBtn.Click += new System.EventHandler(this.uxAddContactBtn_Click);
            // 
            // uxUsernameMainLabel
            // 
            this.uxUsernameMainLabel.AutoSize = true;
            this.uxUsernameMainLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.uxUsernameMainLabel.Location = new System.Drawing.Point(395, 300);
            this.uxUsernameMainLabel.Name = "uxUsernameMainLabel";
            this.uxUsernameMainLabel.Size = new System.Drawing.Size(108, 25);
            this.uxUsernameMainLabel.TabIndex = 11;
            this.uxUsernameMainLabel.Text = "Username:";
            // 
            // uxAddUsername
            // 
            this.uxAddUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.uxAddUsername.Location = new System.Drawing.Point(509, 297);
            this.uxAddUsername.Name = "uxAddUsername";
            this.uxAddUsername.Size = new System.Drawing.Size(200, 30);
            this.uxAddUsername.TabIndex = 10;
            // 
            // uxLoggedInLB
            // 
            this.uxLoggedInLB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.uxLoggedInLB.FormattingEnabled = true;
            this.uxLoggedInLB.ItemHeight = 25;
            this.uxLoggedInLB.Location = new System.Drawing.Point(4, 73);
            this.uxLoggedInLB.Name = "uxLoggedInLB";
            this.uxLoggedInLB.ScrollAlwaysVisible = true;
            this.uxLoggedInLB.Size = new System.Drawing.Size(315, 254);
            this.uxLoggedInLB.TabIndex = 6;
            // 
            // uxAccountLabel
            // 
            this.uxAccountLabel.AutoSize = true;
            this.uxAccountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxAccountLabel.Location = new System.Drawing.Point(4, 0);
            this.uxAccountLabel.Name = "uxAccountLabel";
            this.uxAccountLabel.Size = new System.Drawing.Size(120, 31);
            this.uxAccountLabel.TabIndex = 0;
            this.uxAccountLabel.Text = "Account";
            // 
            // uxStartChatBtn
            // 
            this.uxStartChatBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.uxStartChatBtn.Location = new System.Drawing.Point(3, 333);
            this.uxStartChatBtn.Name = "uxStartChatBtn";
            this.uxStartChatBtn.Size = new System.Drawing.Size(315, 50);
            this.uxStartChatBtn.TabIndex = 4;
            this.uxStartChatBtn.Text = "Start Chat";
            this.uxStartChatBtn.UseVisualStyleBackColor = true;
            this.uxStartChatBtn.Click += new System.EventHandler(this.uxStartChatBtn_Click);
            // 
            // uxRemoveContact
            // 
            this.uxRemoveContact.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.uxRemoveContact.Location = new System.Drawing.Point(566, 333);
            this.uxRemoveContact.Name = "uxRemoveContact";
            this.uxRemoveContact.Size = new System.Drawing.Size(143, 50);
            this.uxRemoveContact.TabIndex = 17;
            this.uxRemoveContact.Text = "Remove";
            this.uxRemoveContact.UseVisualStyleBackColor = true;
            this.uxRemoveContact.Click += new System.EventHandler(this.uxRemoveContact_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(748, 414);
            this.Controls.Add(this.uxMainGB);
            this.Controls.Add(this.uxIPgb);
            this.Controls.Add(this.uxLoginGB);
            this.Name = "MainForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.uxLoginGB.ResumeLayout(false);
            this.uxLoginGB.PerformLayout();
            this.uxIPgb.ResumeLayout(false);
            this.uxIPgb.PerformLayout();
            this.uxMainGB.ResumeLayout(false);
            this.uxMainGB.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label uxLoginLabel;
        private System.Windows.Forms.Button uxLogInBtn;
        private System.Windows.Forms.TextBox uxUsername;
        private System.Windows.Forms.TextBox uxPassword;
        private System.Windows.Forms.Label uxUsernameLabel;
        private System.Windows.Forms.Label uxPasswordLabel;
        private System.Windows.Forms.GroupBox uxLoginGB;
        private System.Windows.Forms.GroupBox uxMainGB;
        private System.Windows.Forms.Label uxContactsLabel;
        private System.Windows.Forms.Label uxOnlineContactsLabel;
        private System.Windows.Forms.ListBox uxContactLB;
        private System.Windows.Forms.Button uxAddContactBtn;
        private System.Windows.Forms.Label uxUsernameMainLabel;
        private System.Windows.Forms.TextBox uxAddUsername;
        private System.Windows.Forms.ListBox uxLoggedInLB;
        private System.Windows.Forms.Label uxAccountLabel;
        private System.Windows.Forms.Button uxStartChatBtn;
        private System.Windows.Forms.Button uxLogoutBtn;
        private System.Windows.Forms.GroupBox uxIPgb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox uxIP;
        private System.Windows.Forms.Button uxIPbtn;
        private System.Windows.Forms.Button uxRemoveContact;
    }
}

