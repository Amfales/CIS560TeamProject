﻿/***************************************************************
 * Names: Andrew Fales, Nathan Helgeson, and Grant Willford
 * Due Date: 10/30/17
 * CIS 501 Final Project Server Side
 ***************************************************************
 * This project consists of a simple chat server with options
 * to add and remove contacts, and to chat with those contacts.
 * It uses Websockets to communicate, and the Server side also
 * uses full MVC to allow for communication between the parts,
 * using delegates.
 ***************************************************************
 * This class is part of the model. It is used to keep track of
 * all the users on the server side. It uses a variety of 
 * dictionaries to keep track of all the accounts, as
 * well as who is online.
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using SharedLibrary;
using Newtonsoft.Json;
using System.Windows.Forms;

namespace FinalProject_Server
{
    public class UserAccountDB
    {
        private string _fileName;//Will always be the same thing.
        private Dictionary<string, Account> _userAccounts;//A dictionary of the accounts stored by the database, the string is their username
        private Dictionary<string, bool> _isOnline;//A dictionary of username to boolean, with true meaning they are online, false not.
        private Dictionary<Account, OnlineAccount> _onlineAccounts;//A dictionary of the online versions of all accounts that are online.
        /// <summary>
        /// This constructor sets the filename, initializes the dictionaries, and then loads any previous
        /// data that is stored in the text file, as a deserialized version of this data type.
        /// It then ends by setting all users as offline.
        /// </summary>
        public UserAccountDB()
        {
            _fileName = "UserAccountDBJSON.txt";
            _isOnline = new Dictionary<string, bool>();
            _onlineAccounts = new Dictionary<Account, OnlineAccount>();
            open();
            foreach (string u in _userAccounts.Keys)
            {
                _isOnline[u] = false;
            }
        }
        /// <summary>
        /// This initializes the UserAccountDB with the necessary user info from the
        /// other database that is given.
        /// </summary>
        /// <param name="other">The other account to be copied.</param>
        public UserAccountDB(UserAccountDB other)
        {
            _fileName = other._fileName;
            _userAccounts = other._userAccounts;
        }
        /// <summary>
        /// Updates the accounts to set them as online. It then needs to update
        /// the list of online friends for all of their friends. This will allow
        /// them to see that their friend is online, now that they have logged in.
        /// </summary>
        /// <param name="a">The account to be set online.</param>
        /// <returns>A List<string> of all the usernames that now have a new friend online.</returns>
        public List<string> SetOnline(Account a)
        {
            if (!_userAccounts.ContainsKey(a.Username)) return null;
            List<string> temp = new List<string>();//A list of usernames that have the new friend.
            //tell everyone who is friends with a that a is online
            foreach (OnlineAccount onAcc in _onlineAccounts.Values)
            {
                if (onAcc.Friends.Contains(a.Username))
                {
                    onAcc.OnlineFriends.Add(a.Username);
                    temp.Add(onAcc.Username);
                }
            }
            _isOnline[a.Username] = true;
            _onlineAccounts[a] = new OnlineAccount(a);
            //Need to set all online friends for the new account that is online.
            foreach(string f in a.Friends)
            {
                if (_isOnline[f]) _onlineAccounts[a].AddOnlineFriend(f);
            }
            return temp;//Return the List<string> of all the usernames that now have a new friend online.
        }
        /// <summary>
        /// Change all the necessary info to mark a user as now being offline.
        /// This is basically a reverse of the SetOnline method.
        /// </summary>
        /// <param name="a">THe account to be set offline.</param>
        /// <returns>A List<string> of all the usernames that no longer have this friend online.</returns>
        public List<string> SetOffline(Account a)
        {
            if (!_userAccounts.ContainsKey(a.Username)) return null;
            //tell everyone who is friends with a that a is offline
            List<string> temp = new List<string>();//The list that will contain all changed account usernames.
            foreach (OnlineAccount onAcc in _onlineAccounts.Values)
            {
                if (onAcc.OnlineFriends.Contains(a.Username))
                {
                    onAcc.OnlineFriends.Remove(a.Username);
                    temp.Add(onAcc.Username);
                }
            }
            _isOnline[a.Username] = false;
            _onlineAccounts.Remove(a);//Simply remove them.
            return temp;
        }
        /// <summary>
        /// This method gets and returns the OnlineAccount, if there
        /// is one for this user. If there is not, it returns null.
        /// </summary>
        /// <param name="username">The username to get the online account of.</param>
        /// <returns>The online account if it exists, null if not.</returns>
        public OnlineAccount GetOnlineAccount(string username)
        {
            Account a = _userAccounts[username];
            if (!_onlineAccounts.ContainsKey(a)) return null;
            return _onlineAccounts[a];
        }
        /// <summary>
        /// Returns whether or not the given user is online.
        /// </summary>
        /// <param name="username">The user to check if they are online.</param>
        /// <returns>True if they are online, false if not.</returns>
        public bool IsOnline(string username)
        {
            if (!_isOnline.ContainsKey(username)) return false;
            return _isOnline[username];
        }
        /// <summary>
        /// This method opens the file and reads in whatever the server had previously saved
        /// of accounts.
        /// </summary>
        private void open()
        {
            StreamReader sr = null;
            try
            {
                sr = new StreamReader(_fileName);//Read from the file if possible.
                
                //UserAccountDB other = JSONizer.ConvertToObject(sr.ReadToEnd()) as UserAccountDB;
                Dictionary<string,Account> temp = JsonConvert.DeserializeObject<Dictionary<string,Account>>(sr.ReadToEnd());
                _userAccounts = temp;
            }
            catch
            {
                _userAccounts = new Dictionary<string, Account>();//If there's no file to read from, just set the dictionary to a new one.
            }
            finally
            {
                if (sr != null)//Need to close the StreamReader if it is still open.
                    sr.Close();
            }
        }
        /// <summary>
        /// This method writes the data stored in the Database to the file when the server is closed.
        /// It does this by Serializing the data through the JSONizer and then storing it in the text
        /// file.
        /// </summary>
        private void WriteDataToFile()
        {
            StreamWriter sw = new StreamWriter(_fileName);
            sw.WriteLine(JSONizer.ConvertToJSON(_userAccounts));
            sw.Close();
        }
        /// <summary>
        /// Add a new account, if possible. If the username already exists in the database, it will
        /// return false. Otherwise, it adds the account to the databse and returns true.
        /// </summary>
        /// <param name="other">The account to try to add.</param>
        /// <returns>True if the account was added, false if the username already existed in the database.</returns>
        public bool AddAccount(Account other)
        {
            if (_userAccounts.ContainsKey(other.Username)) return false;
            _userAccounts.Add(other.Username, other);
            return true;
        }
        /// <summary>
        /// Gets and returns the account for the given username. If the username is not contained in
        /// the databse, it will return null.
        /// </summary>
        /// <param name="username">The username of the account to get.</param>
        /// <returns>Returns either the account or null</returns>
        public Account GetAccount(string username)
        {
            if (_userAccounts.ContainsKey(username))
            {
                return _userAccounts[username];
            }

            return null;
        }

        /// <summary>
        /// Returns whether or not the database contains an account with that username.
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        public bool ContainsAccount(string username)
        {
            return _userAccounts.ContainsKey(username);
        }
        /// <summary>
        /// Returns a list of all of the accounts in _userAccounts
        /// </summary>
        public List<Account> Accounts
        {
            get
            {
                List<Account> temp = new List<Account>();
                foreach (Account whyamidoingthis in _userAccounts.Values)
                {
                    temp.Add(whyamidoingthis);
                }
                return temp;
            }
        }
        /// <summary>
        /// When the Server closes, it calls this method to write all the data
        /// stored in the database to the file.
        /// </summary>
        public void Close()
        {
            WriteDataToFile();
        }
    }
}
