﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebSocketSharp;
using SharedLibrary;

//
namespace FinalProjectT3_5
{


    public partial class ChatForm : Form
    {
        /// <summary>
        /// The conversation object this ChatForm represents
        /// </summary>
        private SharedLibrary.Conversation _convo;

        /// <summary>
        /// The current user
        /// </summary>
        private string _User;

        /// <summary>
        /// The controller
        /// </summary>
        private ClientChatSocket _socket;

        /// <summary>
        /// The constructor for the ChatForm class. Initializes all components and creates a Load function for the form.
        /// </summary>
        /// <param name="c">The conversation</param>
        /// <param name="user">The current user</param>
        /// <param name="socket">The controller object</param>
        public ChatForm(Conversation c, string user, ClientChatSocket socket)
        {
            _socket = socket;
            _User = user;
            _convo = c;
           
            this.Load += (sender, e) => Invoke(new Action(() =>
             {
                 InitializeComponent();
                 this.Text = "Chat - " + _User;
                 uxMutualFriendsLB.DataSource = _convo.MutualFriends;
                 uxChattersLB.DataSource = _convo.Users;
                 uxChatBox.DataSource = _convo.Lines;
                 uxChatBox.TopIndex = uxChatBox.Items.Count - 1;

                 uxMessage.KeyDown += (sender2, e2) => { if (e2.KeyCode == Keys.Enter) uxSendMessage_Click(sender2, e2); };
             }));

        }

        /// <summary>
        /// Sends an AddToChatRequest to the server based on the selected user
        /// </summary>
        /// <param name="sender">The mutual friends listbox</param>
        /// <param name="e">The event arguments</param>
        private void uxAddToChatBtn_Click(object sender, EventArgs e)
        {
            string user = "" + uxMutualFriendsLB.SelectedItem;
            SharedLibrary.Message addtochat = new SharedLibrary.Message(SharedLibrary.MessageType.AddToChatRequest, new object[] { _User, user, _convo.uID });
            _socket.SendMessage(addtochat);
        }

        /// <summary>
        ///Sends a SendChatMessage object to the server containing the given message
        /// </summary>
        /// <param name="sender">The send message button</param>
        /// <param name="e">The event arguments</param>
        private void uxSendMessage_Click(object sender, EventArgs e)
        {
            string raw = uxMessage.Text;
            if (raw == "") return;
            SharedLibrary.Message sendchat = new SharedLibrary.Message(SharedLibrary.MessageType.SendChatMessage, new object[] { _User, _convo.uID, raw });
            _socket.SendMessage(sendchat);
            uxMessage.Text = "";
        }

        /// <summary>
        /// Updates the form from a new conversation
        /// </summary>
        /// <param name="c">The new conversation object</param>
        public void UpdateChat(Conversation c)
        {
            _convo = c;

            Invoke(new Action(() =>
            {
                uxMutualFriendsLB.DataSource = new List<string>(_convo.MutualFriends);
                uxChattersLB.DataSource = new List<string>(_convo.Users);
                uxChatBox.DataSource = new List<string>(_convo.Lines);
                uxChatBox.TopIndex = uxChatBox.Items.Count - 1;
            }));
        }

        /// <summary>
        /// Updates the chat display with a new message
        /// </summary>
        /// <param name="msg">The new message to be displayed</param>
        public void UpdateLines(string msg)
        {
            _convo.AddLine(msg);
            Invoke(new Action(() =>
            {
                uxChatBox.DataSource = new List<string>(_convo.Lines);
                uxChatBox.TopIndex = uxChatBox.Items.Count - 1;
            }));
        }

        /// <summary>
        /// The closing event for the form. Sends a LeaveChatRequest to the server
        /// </summary>
        /// <param name="sender">The form itself</param>
        /// <param name="e">The event arguments</param>
        private void ChatForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            SharedLibrary.Message sendchat = new SharedLibrary.Message(SharedLibrary.MessageType.LeaveChatRequst, new object[] { _User, _convo.uID });
            _socket.SendMessage(sendchat);
        }
    }
}
