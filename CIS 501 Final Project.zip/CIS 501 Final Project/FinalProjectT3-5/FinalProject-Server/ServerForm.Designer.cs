﻿namespace FinalProject_Server
{
    partial class ServerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uxOnlineBox = new System.Windows.Forms.ListBox();
            this.uxOfflineBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.uxGetUserInfo = new System.Windows.Forms.Button();
            this.uxServInfoBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.uxUserGroup = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.uxConvoBox = new System.Windows.Forms.ListBox();
            this.uxUserGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // uxOnlineBox
            // 
            this.uxOnlineBox.FormattingEnabled = true;
            this.uxOnlineBox.Location = new System.Drawing.Point(5, 16);
            this.uxOnlineBox.Name = "uxOnlineBox";
            this.uxOnlineBox.Size = new System.Drawing.Size(120, 95);
            this.uxOnlineBox.TabIndex = 0;
            this.uxOnlineBox.SelectedIndexChanged += new System.EventHandler(this.uxOnlineBox_SelectedIndexChanged);
            // 
            // uxOfflineBox
            // 
            this.uxOfflineBox.FormattingEnabled = true;
            this.uxOfflineBox.Location = new System.Drawing.Point(131, 15);
            this.uxOfflineBox.Name = "uxOfflineBox";
            this.uxOfflineBox.Size = new System.Drawing.Size(120, 95);
            this.uxOfflineBox.TabIndex = 1;
            this.uxOfflineBox.SelectedIndexChanged += new System.EventHandler(this.uxOfflineBox_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Online Users:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(142, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Offline Users:";
            // 
            // uxGetUserInfo
            // 
            this.uxGetUserInfo.Enabled = false;
            this.uxGetUserInfo.Location = new System.Drawing.Point(79, 129);
            this.uxGetUserInfo.Name = "uxGetUserInfo";
            this.uxGetUserInfo.Size = new System.Drawing.Size(125, 23);
            this.uxGetUserInfo.TabIndex = 5;
            this.uxGetUserInfo.Text = "Get Selected User Info";
            this.uxGetUserInfo.UseVisualStyleBackColor = true;
            this.uxGetUserInfo.Click += new System.EventHandler(this.uxGetUserInfo_Click);
            // 
            // uxServInfoBox
            // 
            this.uxServInfoBox.Location = new System.Drawing.Point(12, 167);
            this.uxServInfoBox.Multiline = true;
            this.uxServInfoBox.Name = "uxServInfoBox";
            this.uxServInfoBox.ReadOnly = true;
            this.uxServInfoBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.uxServInfoBox.Size = new System.Drawing.Size(516, 82);
            this.uxServInfoBox.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 151);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Server Operations:";
            // 
            // uxUserGroup
            // 
            this.uxUserGroup.Controls.Add(this.label4);
            this.uxUserGroup.Controls.Add(this.uxConvoBox);
            this.uxUserGroup.Controls.Add(this.label3);
            this.uxUserGroup.Controls.Add(this.label1);
            this.uxUserGroup.Controls.Add(this.uxOfflineBox);
            this.uxUserGroup.Controls.Add(this.uxOnlineBox);
            this.uxUserGroup.Location = new System.Drawing.Point(7, 12);
            this.uxUserGroup.Name = "uxUserGroup";
            this.uxUserGroup.Size = new System.Drawing.Size(527, 116);
            this.uxUserGroup.TabIndex = 8;
            this.uxUserGroup.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(254, -1);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Conversations:";
            // 
            // uxConvoBox
            // 
            this.uxConvoBox.FormattingEnabled = true;
            this.uxConvoBox.Location = new System.Drawing.Point(257, 15);
            this.uxConvoBox.Name = "uxConvoBox";
            this.uxConvoBox.Size = new System.Drawing.Size(264, 95);
            this.uxConvoBox.TabIndex = 5;
            // 
            // ServerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 265);
            this.Controls.Add(this.uxGetUserInfo);
            this.Controls.Add(this.uxUserGroup);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.uxServInfoBox);
            this.Name = "ServerForm";
            this.Text = "ServerForm";
            this.uxUserGroup.ResumeLayout(false);
            this.uxUserGroup.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox uxOnlineBox;
        private System.Windows.Forms.ListBox uxOfflineBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button uxGetUserInfo;
        private System.Windows.Forms.TextBox uxServInfoBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox uxUserGroup;
        private System.Windows.Forms.ListBox uxConvoBox;
        private System.Windows.Forms.Label label4;
    }
}