﻿/***************************************************************
 * Names: Andrew Fales, Nathan Helgeson, and Grant Willford
 * Due Date: 10/30/17
 * CIS 501 Final Project Server Side
 ***************************************************************
 * This project consists of a simple chat server with options
 * to add and remove contacts, and to chat with those contacts.
 * It uses Websockets to communicate, and the Server side also
 * uses full MVC to allow for communication between the parts,
 * using delegates.
 ***************************************************************
 * This class is the part of the class that has the WebSocketServer.
 * It is where the server actually runs.
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebSocketSharp;
using WebSocketSharp.Server;
using SharedLibrary;
using System.Windows.Forms;

namespace FinalProject_Server
{
    class ServerChatBehavior : WebSocketBehavior
    {
        private OnReceive _o;
        public ServerChatBehavior(OnReceive o)
        {
            _o = o;
        }

        /// <summary>
        /// Handler for recieving an incomming message
        /// </summary>
        /// <param name="e">The event args</param>
        protected override void OnMessage(MessageEventArgs e)
        {
            string jsonString = e.Data;
            SharedLibrary.Message m = JSONizer.ConvertToMessage(jsonString);
            if (m != null)
            {
                _o(ID, m);
            }
        }
    }
}
