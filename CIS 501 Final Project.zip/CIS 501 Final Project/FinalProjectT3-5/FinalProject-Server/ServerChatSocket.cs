﻿/***************************************************************
 * Names: Andrew Fales, Nathan Helgeson, and Grant Willford
 * Due Date: 10/30/17
 * CIS 501 Final Project Server Side
 ***************************************************************
 * This project consists of a simple chat server with options
 * to add and remove contacts, and to chat with those contacts.
 * It uses Websockets to communicate, and the Server side also
 * uses full MVC to allow for communication between the parts,
 * using delegates.
 ***************************************************************
 * This class is the part of the class that has the WebSocketServer.
 * It is where the server actually runs.
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebSocketSharp;
using WebSocketSharp.Server;
using SharedLibrary;
using System.Windows.Forms;

namespace FinalProject_Server
{
    class ServerChatSocket
    {
        private WebSocketServer wss;
        private OnReceive _o; // Controller delegate to handle messages

        private WebSocketServiceHost _sock;

        public ServerChatSocket(OnReceive o)
        {
            wss = new WebSocketServer(8001);
            _o = o;
            wss.AddWebSocketService<ServerChatBehavior>("/chat", buildSock);
        }

        // This is a hack method to "simulate" a two way connection without having to have a server on the client.
        /// <summary>
        /// This method Sends an IMessage to a client with a given session ID
        /// </summary>
        /// <param name="m">The message to send</param>
        /// <param name="sessID">The client's session id</param>
        public void SendMessage(IMessage m, string sessID)
        {
            if (_sock == null)
            {
                if (!wss.WebSocketServices.TryGetServiceHost("/chat", out _sock))
                {
                    throw new Exception("Ahhhhhh!!!!!!!!!!!");
                }
            }
            // _sock is now set
            _sock.Sessions.SendTo(JSONizer.ConvertToJSON(m), sessID); // Send JSON string of message
        }

        public void StartServer()
        {
            wss.Start();
        }

        public void StopServer()
        {
            wss.Stop();
        }

        /// <summary>
        /// Builds the ServerSocket
        /// </summary>
        /// <returns>Returns a new ServerChatBehavior passing the delegate</returns>
        private ServerChatBehavior buildSock()
        {
            return new ServerChatBehavior(_o);
        }
    }
}
