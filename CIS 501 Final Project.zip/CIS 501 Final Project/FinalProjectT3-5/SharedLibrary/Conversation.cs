﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedLibrary
{
    public class Conversation
    {
        private List<string> _lines;
        private List<string> _mutualFriends;
        private int _uID;
        private List<string> _users;

        public Conversation()
        {
            _lines = new List<string>();
            _users = new List<string>();
            _mutualFriends = new List<string>();
        }

        /// <summary>
        /// Constructor for conversation that requires the first two people to form the conversation.
        /// This constructor requires that the two passed accounts are friends
        /// </summary>
        /// <param name="id">The unique ID for this conversation</param>
        /// <param name="first">The first account to add to this conversation</param>
        /// <param name="second">The second account to add to this conversation</param>
        public Conversation(int id, OnlineAccount first, OnlineAccount second)
        {
            //assumes that first and second are friends
            _uID = id;
            _lines = new List<string>();
            _users = new List<string>();
            _users.Add(first.Username);
            _mutualFriends = new List<string>();
            
            foreach (string f in first.OnlineFriends)
            {
                _mutualFriends.Add(f);
            }
            AddUser(second);
        }
        public List<string> Lines
        {
            get
            {
                return _lines;
            }
            set
            {
                _lines = value;
            }
        }

        /// <summary>
        /// Add a new message to this conversation's list
        /// </summary>
        /// <param name="msg">The message to be added</param>
        public void AddLine(string msg)
        {
            _lines.Add(msg);
        }

        /// <summary>
        /// Adds the passed user to this conversation so long as it is a mutual friend
        /// of all current users
        /// </summary>
        /// <param name="other">The account to be added</param>
        /// <returns>true if successful, false if could not be added</returns>
        public bool AddUser(OnlineAccount other)
        {
            if (!_mutualFriends.Contains(other.Username)) return false;

            _users.Add(other.Username);
            _mutualFriends = _mutualFriends.Intersect(other.OnlineFriends).ToList<string>();
            return true;
        }

        public bool DeleteUser(Account other)
        {
            if (!_users.Contains(other.Username)) return false;

            _users.Remove(other.Username);
            return true;
        }

        public string UserString(string username)
        {

            StringBuilder result = new StringBuilder();
            foreach (string member in _users)
            {
                //we only want to print the other users in the chat, so don't add the member if it's
                //the current username
                if (username == member) continue;
                result.Append(member + ", ");
            }
            result.Length -= 2;
            return (result.ToString());
        }

        public List<string> MutualFriends
        {
            get
            {
                return _mutualFriends;
            }
            set
            {
                _mutualFriends = value;
            }
        }

        public List<string> Users
        {
            get
            {
                return _users;
            }
            set
            {
                _users = value;
            }
        }

        public int uID
        {
            get
            {
                return _uID;
            }
            set
            {
                _uID = value;
            }
        }
    }
}