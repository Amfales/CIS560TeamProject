﻿/***************************************************************
 * Names: Andrew Fales, Nathan Helgeson, and Grant Willford
 * Due Date: 10/30/17
 * CIS 501 Final Project Server Side
 ***************************************************************
 * This project consists of a simple chat server with options
 * to add and remove contacts, and to chat with those contacts.
 * It uses Websockets to communicate, and the Server side also
 * uses full MVC to allow for communication between the parts,
 * using delegates.
 ***************************************************************
 * This class is the database class that keeps track of the
 * conversations that are currently running. It uses a dictionary
 * to do so, and keeps all in it.
 ***************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharedLibrary;

namespace FinalProject_Server
{
    class ConversationDB
    {
        private Dictionary<int, Conversation> _conversations;//The Dictionary of all the conversations mapped to their id.
        private int _nextUID;//The next Id to make a conversation at.
        /// <summary>
        /// The constructor initializes the DB and nextuID to be set at the default for the start of the server.
        /// </summary>
        public ConversationDB()
        {
            _conversations = new Dictionary<int, Conversation>();
            _nextUID = 0;
        }
        /// <summary>
        /// Adds a conversation between the two given OnlineAccounts. It adds the new convo to the database, 
        /// and returns the value of the convo ID.
        /// </summary>
        /// <param name="first">First account to be added to the conversation.</param>
        /// <param name="second">Second account to be added to the conversation.</param>
        /// <returns>The value of the conversation ID.</returns>
        public int AddConversation(OnlineAccount first, OnlineAccount second)
        {
            _conversations.Add(_nextUID, new Conversation(_nextUID, first, second));
            _nextUID++;
            return _nextUID - 1;
        }
        /// <summary>
        /// Gets the conversation that has the given ID.
        /// </summary>
        /// <param name="id">The ID of the convo you want to get.</param>
        /// <returns>null if the convo doesn't exit, the Convo if it does.</returns>
        public Conversation Get(int id)
        {
            if (!_conversations.ContainsKey(id)) return null;
            return _conversations[id];
        }
        /// <summary>
        /// This returns a list of the conversations that the username takes part in.
        /// </summary>
        /// <param name="username"></param>
        /// <returns>Returns a list of all conversations the given user is in.</returns>
        public List<Conversation> GetUserConversations(string username)
        {
            List<Conversation> result = new List<Conversation>();

            foreach(Conversation c in _conversations.Values)
            {
                if (c.Users.Contains(username))
                {
                    result.Add(c);
                }
            }

            return result;
        }
        /// <summary>
        /// Returns a list of strings that contains the usernames of all the users in
        /// all of the converstaions.
        /// </summary>
        /// <returns></returns>
        public List<string> GetUserStrings()
        {
            List<string> temp = new List<string>();
            foreach (Conversation c in _conversations.Values)
            {
                temp.Add(c.UserString(null));
            }
            return temp;
        }
        /// <summary>
        /// This method removes somebody from a conversation.
        /// The given account and convID are used to determine who
        /// to remove from the conversation, and where to remove them.
        /// </summary>
        /// <param name="acc">The Account to be removed.</param>
        /// <param name="convID">The ID of the conversation to be removed from.</param>
        /// <returns>True if there are still enough people to continue the conversation, false if not.</returns>
        public bool RemoveFromConv(Account acc, int convID)
        {
            Conversation conv = _conversations[convID];
            conv.DeleteUser(acc);
            if (conv.Users.Count <= 1)
            {
                return false;
            }
            return true;
        }
        /// <summary>
        /// Removes the conversation with the given ID from the databse.
        /// </summary>
        /// <param name="convID">The ID of the conversation to remove.</param>
        /// <returns>True if the converstaion was removed, false if it couldn't remove it.</returns>
        public bool RemoveConv(int convID)
        {
            return _conversations.Remove(convID);
        }
    }
}
