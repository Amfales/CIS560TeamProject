﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebSocketSharp;
using SharedLibrary;

namespace FinalProject_Server
{
    public partial class DummyClient : Form
    {
        private WebSocket ws;
        private Dictionary<Button, string[]> look;

        public DummyClient(bool suppress)
        {
            InitializeComponent();
            ws = new WebSocket("ws://127.0.0.1:8001/chat");
            ws.Connect();
            ws.OnMessage += (sender, e) => { if (!suppress) MessageBox.Show(e.Data); };
            buildLookup();
            foreach(Label l in new Label[] { label1, label2, label3 })
            {
                l.Text = "";
            }
            foreach (Button b in new Button[] { button10, button11, button12, button13, button14, button15 })
            {
                b.MouseHover += (sender, e) => { string[] a = look[b]; label1.Text = a[0]; label2.Text = a[1]; label3.Text = a[2]; };
            }
        }

        public void buildLookup()
        {
            look = new Dictionary<Button, string[]>();
            look[button10] = new string[] {"Username","Password","" }; //login
            look[button11] = new string[] {"First Username","Second Username", ""}; //add friend
            look[button12] = new string[] { "First Username", "Second Username", "" }; //start chat
            look[button13] = new string[] { "User to Add", "Chat ID", "" }; //add to chat
            look[button14] = new string[] { "Username", "Chat ID", "Message" }; //send message
            look[button15] = new string[] { "Username to Logout", "", "" }; //logout
        }

        public void CloseSocket()
        {
            ws.Close();
        }

        //Log in as DummyUser
        private void button1_Click(object sender, EventArgs e)
        {
            MessageType mt = MessageType.LogInRequest;
            object[] args = new object[2];
            args[0] = "DummyUser"; args[1] = "DummyPass";
            SharedLibrary.Message m = new SharedLibrary.Message(mt,args);
            ws.Send(JSONizer.ConvertMessageToJSON(m));
        }

        
        //Log in as DummyUser2
        private void button2_Click(object sender, EventArgs e)
        {
            MessageType mt = MessageType.LogInRequest;
            object[] args = new object[2];
            args[0] = "DummyUser2"; args[1] = "DummyPass2";
            SharedLibrary.Message m = new SharedLibrary.Message(mt, args);
            ws.Send(JSONizer.ConvertMessageToJSON(m));
        }

        //Add DummyUser2 as Friend for DummyUser
        private void button3_Click(object sender, EventArgs e)
        {
            MessageType mt = MessageType.AddFriendRequest;
            object[] args = new object[2];
            args[0] = "DummyUser"; args[1] = "DummyUser2";
            SharedLibrary.Message m = new SharedLibrary.Message(mt, args);
            ws.Send(JSONizer.ConvertMessageToJSON(m));
        }

        //Start chat between DummyUser and DummyUser2
        private void button4_Click(object sender, EventArgs e)
        {
            MessageType mt = MessageType.StartChatRequest;
            object[] args = new object[2];
            args[0] = "DummyUser"; args[1] = "DummyUser2";
            SharedLibrary.Message m = new SharedLibrary.Message(mt, args);
            ws.Send(JSONizer.ConvertMessageToJSON(m));
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageType mt = MessageType.SendChatMessage;
            object[] args = new object[3];
            args[0] = "DummyUser"; args[1] = 0; args[2] = "Hello from DummyUser";
            SharedLibrary.Message m = new SharedLibrary.Message(mt, args);
            ws.Send(JSONizer.ConvertMessageToJSON(m));
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageType mt = MessageType.SendChatMessage;
            object[] args = new object[3];
            args[0] = "DummyUser2"; args[1] = 0; args[2] = "Hello from DummyUser2";
            SharedLibrary.Message m = new SharedLibrary.Message(mt, args);
            ws.Send(JSONizer.ConvertMessageToJSON(m));
        }

        private void button7_Click(object sender, EventArgs e)
        {
            MessageType mt = MessageType.LogOutRequest;
            object[] args = new object[1];
            args[0] = "DummyUser";
            SharedLibrary.Message m = new SharedLibrary.Message(mt, args);
            ws.Send(JSONizer.ConvertMessageToJSON(m));
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MessageType mt = MessageType.LogOutRequest;
            object[] args = new object[1];
            args[0] = "DummyUser2";
            SharedLibrary.Message m = new SharedLibrary.Message(mt, args);
            ws.Send(JSONizer.ConvertMessageToJSON(m));
        }

        private void button9_Click(object sender, EventArgs e)
        {
            MessageType mt = MessageType.AddFriendRequest;
            object[] args = new object[2];
            args[0] = "DummyUser2"; args[1] = "DummyUser";
            SharedLibrary.Message m = new SharedLibrary.Message(mt, args);
            ws.Send(JSONizer.ConvertMessageToJSON(m));
        }

        //Log in as anyone
        private void button10_Click(object sender, EventArgs e)
        {
            MessageType mt = MessageType.LogInRequest;
            object[] args = new object[2];
            args[0] = textBox1.Text; args[1] = textBox2.Text;
            SharedLibrary.Message m = new SharedLibrary.Message(mt, args);
            ws.Send(JSONizer.ConvertMessageToJSON(m));
        }

        //Add anyone as friend
        private void button11_Click(object sender, EventArgs e)
        {
            MessageType mt = MessageType.AddFriendRequest;
            object[] args = new object[2];
            args[0] = textBox1.Text; args[1] = textBox2.Text;
            SharedLibrary.Message m = new SharedLibrary.Message(mt, args);
            ws.Send(JSONizer.ConvertMessageToJSON(m));
        }

        //Start chat between anyone
        private void button12_Click(object sender, EventArgs e)
        {
            MessageType mt = MessageType.StartChatRequest;
            object[] args = new object[2];
            args[0] = textBox1.Text; args[1] = textBox2.Text;
            SharedLibrary.Message m = new SharedLibrary.Message(mt, args);
            ws.Send(JSONizer.ConvertMessageToJSON(m));
        }

        //Add anyone to chat
        private void button13_Click(object sender, EventArgs e)
        {
            MessageType mt = MessageType.AddToChatRequest;
            object[] args = new object[3];
            args[0] = textBox1.Text; args[1] = textBox2.Text; args[2] = textBox3.Text; //oUserName, chatID
            SharedLibrary.Message m = new SharedLibrary.Message(mt, args);
            ws.Send(JSONizer.ConvertMessageToJSON(m));
        }

        //Anyone say anything
        private void button14_Click(object sender, EventArgs e)
        {
            MessageType mt = MessageType.SendChatMessage;
            object[] args = new object[3];
            args[0] = textBox1.Text; args[1] = textBox2.Text; args[2] = textBox3.Text;
            //Username, chatID, Message
            SharedLibrary.Message m = new SharedLibrary.Message(mt, args);
            ws.Send(JSONizer.ConvertMessageToJSON(m));
        }

        private void button15_Click(object sender, EventArgs e)
        {
            MessageType mt = MessageType.LogOutRequest;
            object[] args = new object[1];
            args[0] = textBox1.Text;
            SharedLibrary.Message m = new SharedLibrary.Message(mt, args);
            ws.Send(JSONizer.ConvertMessageToJSON(m));
        }
    }
}
